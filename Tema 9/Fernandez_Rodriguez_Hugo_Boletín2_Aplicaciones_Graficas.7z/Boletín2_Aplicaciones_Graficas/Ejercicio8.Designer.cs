﻿namespace Boletín2_Aplicaciones_Graficas
{
    partial class Ejercicio8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPull = new System.Windows.Forms.Button();
            this.pictureBoxDadoNumero6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero4 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero1Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero2Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero3Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero4Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero5Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero6Segundo = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero1Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero2Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero3Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero4Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero5Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero6Tercero = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero1Cuarto = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero2Cuarto = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero3Cuarto = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero4Cuarto = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero5Cuarto = new System.Windows.Forms.PictureBox();
            this.pictureBoxDadoNumero6Cuarto = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Segundo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Tercero)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Cuarto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Cuarto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Cuarto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Cuarto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Cuarto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Cuarto)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPull
            // 
            this.btnPull.Location = new System.Drawing.Point(139, 168);
            this.btnPull.Name = "btnPull";
            this.btnPull.Size = new System.Drawing.Size(98, 25);
            this.btnPull.TabIndex = 4;
            this.btnPull.Text = "Pull";
            this.btnPull.UseVisualStyleBackColor = true;
            this.btnPull.Click += new System.EventHandler(this.btnPull_Click);
            // 
            // pictureBoxDadoNumero6
            // 
            this.pictureBoxDadoNumero6.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_6;
            this.pictureBoxDadoNumero6.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero6.Name = "pictureBoxDadoNumero6";
            this.pictureBoxDadoNumero6.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero6.TabIndex = 6;
            this.pictureBoxDadoNumero6.TabStop = false;
            this.pictureBoxDadoNumero6.Visible = false;
            // 
            // pictureBoxDadoNumero5
            // 
            this.pictureBoxDadoNumero5.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_5;
            this.pictureBoxDadoNumero5.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero5.Name = "pictureBoxDadoNumero5";
            this.pictureBoxDadoNumero5.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero5.TabIndex = 5;
            this.pictureBoxDadoNumero5.TabStop = false;
            this.pictureBoxDadoNumero5.Visible = false;
            // 
            // pictureBoxDadoNumero4
            // 
            this.pictureBoxDadoNumero4.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_4;
            this.pictureBoxDadoNumero4.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero4.Name = "pictureBoxDadoNumero4";
            this.pictureBoxDadoNumero4.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero4.TabIndex = 3;
            this.pictureBoxDadoNumero4.TabStop = false;
            this.pictureBoxDadoNumero4.Visible = false;
            // 
            // pictureBoxDadoNumero3
            // 
            this.pictureBoxDadoNumero3.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_3;
            this.pictureBoxDadoNumero3.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero3.Name = "pictureBoxDadoNumero3";
            this.pictureBoxDadoNumero3.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero3.TabIndex = 2;
            this.pictureBoxDadoNumero3.TabStop = false;
            this.pictureBoxDadoNumero3.Visible = false;
            // 
            // pictureBoxDadoNumero2
            // 
            this.pictureBoxDadoNumero2.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_2;
            this.pictureBoxDadoNumero2.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero2.Name = "pictureBoxDadoNumero2";
            this.pictureBoxDadoNumero2.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero2.TabIndex = 1;
            this.pictureBoxDadoNumero2.TabStop = false;
            this.pictureBoxDadoNumero2.Visible = false;
            // 
            // pictureBoxDadoNumero1
            // 
            this.pictureBoxDadoNumero1.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_1;
            this.pictureBoxDadoNumero1.Location = new System.Drawing.Point(117, 49);
            this.pictureBoxDadoNumero1.Name = "pictureBoxDadoNumero1";
            this.pictureBoxDadoNumero1.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero1.TabIndex = 0;
            this.pictureBoxDadoNumero1.TabStop = false;
            this.pictureBoxDadoNumero1.Visible = false;
            // 
            // pictureBoxDadoNumero1Segundo
            // 
            this.pictureBoxDadoNumero1Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_1;
            this.pictureBoxDadoNumero1Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero1Segundo.Name = "pictureBoxDadoNumero1Segundo";
            this.pictureBoxDadoNumero1Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero1Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero1Segundo.TabIndex = 7;
            this.pictureBoxDadoNumero1Segundo.TabStop = false;
            this.pictureBoxDadoNumero1Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero2Segundo
            // 
            this.pictureBoxDadoNumero2Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_2;
            this.pictureBoxDadoNumero2Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero2Segundo.Name = "pictureBoxDadoNumero2Segundo";
            this.pictureBoxDadoNumero2Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero2Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero2Segundo.TabIndex = 8;
            this.pictureBoxDadoNumero2Segundo.TabStop = false;
            this.pictureBoxDadoNumero2Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero3Segundo
            // 
            this.pictureBoxDadoNumero3Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_3;
            this.pictureBoxDadoNumero3Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero3Segundo.Name = "pictureBoxDadoNumero3Segundo";
            this.pictureBoxDadoNumero3Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero3Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero3Segundo.TabIndex = 9;
            this.pictureBoxDadoNumero3Segundo.TabStop = false;
            this.pictureBoxDadoNumero3Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero4Segundo
            // 
            this.pictureBoxDadoNumero4Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_4;
            this.pictureBoxDadoNumero4Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero4Segundo.Name = "pictureBoxDadoNumero4Segundo";
            this.pictureBoxDadoNumero4Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero4Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero4Segundo.TabIndex = 10;
            this.pictureBoxDadoNumero4Segundo.TabStop = false;
            this.pictureBoxDadoNumero4Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero5Segundo
            // 
            this.pictureBoxDadoNumero5Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_5;
            this.pictureBoxDadoNumero5Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero5Segundo.Name = "pictureBoxDadoNumero5Segundo";
            this.pictureBoxDadoNumero5Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero5Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero5Segundo.TabIndex = 11;
            this.pictureBoxDadoNumero5Segundo.TabStop = false;
            this.pictureBoxDadoNumero5Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero6Segundo
            // 
            this.pictureBoxDadoNumero6Segundo.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_6;
            this.pictureBoxDadoNumero6Segundo.Location = new System.Drawing.Point(193, 49);
            this.pictureBoxDadoNumero6Segundo.Name = "pictureBoxDadoNumero6Segundo";
            this.pictureBoxDadoNumero6Segundo.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero6Segundo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero6Segundo.TabIndex = 12;
            this.pictureBoxDadoNumero6Segundo.TabStop = false;
            this.pictureBoxDadoNumero6Segundo.Visible = false;
            // 
            // pictureBoxDadoNumero1Tercero
            // 
            this.pictureBoxDadoNumero1Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_1;
            this.pictureBoxDadoNumero1Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero1Tercero.Name = "pictureBoxDadoNumero1Tercero";
            this.pictureBoxDadoNumero1Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero1Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero1Tercero.TabIndex = 13;
            this.pictureBoxDadoNumero1Tercero.TabStop = false;
            this.pictureBoxDadoNumero1Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero2Tercero
            // 
            this.pictureBoxDadoNumero2Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_2;
            this.pictureBoxDadoNumero2Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero2Tercero.Name = "pictureBoxDadoNumero2Tercero";
            this.pictureBoxDadoNumero2Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero2Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero2Tercero.TabIndex = 14;
            this.pictureBoxDadoNumero2Tercero.TabStop = false;
            this.pictureBoxDadoNumero2Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero3Tercero
            // 
            this.pictureBoxDadoNumero3Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_3;
            this.pictureBoxDadoNumero3Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero3Tercero.Name = "pictureBoxDadoNumero3Tercero";
            this.pictureBoxDadoNumero3Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero3Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero3Tercero.TabIndex = 15;
            this.pictureBoxDadoNumero3Tercero.TabStop = false;
            this.pictureBoxDadoNumero3Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero4Tercero
            // 
            this.pictureBoxDadoNumero4Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_4;
            this.pictureBoxDadoNumero4Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero4Tercero.Name = "pictureBoxDadoNumero4Tercero";
            this.pictureBoxDadoNumero4Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero4Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero4Tercero.TabIndex = 16;
            this.pictureBoxDadoNumero4Tercero.TabStop = false;
            this.pictureBoxDadoNumero4Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero5Tercero
            // 
            this.pictureBoxDadoNumero5Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_5;
            this.pictureBoxDadoNumero5Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero5Tercero.Name = "pictureBoxDadoNumero5Tercero";
            this.pictureBoxDadoNumero5Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero5Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero5Tercero.TabIndex = 17;
            this.pictureBoxDadoNumero5Tercero.TabStop = false;
            this.pictureBoxDadoNumero5Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero6Tercero
            // 
            this.pictureBoxDadoNumero6Tercero.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_6;
            this.pictureBoxDadoNumero6Tercero.Location = new System.Drawing.Point(117, 117);
            this.pictureBoxDadoNumero6Tercero.Name = "pictureBoxDadoNumero6Tercero";
            this.pictureBoxDadoNumero6Tercero.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero6Tercero.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero6Tercero.TabIndex = 18;
            this.pictureBoxDadoNumero6Tercero.TabStop = false;
            this.pictureBoxDadoNumero6Tercero.Visible = false;
            // 
            // pictureBoxDadoNumero1Cuarto
            // 
            this.pictureBoxDadoNumero1Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_1;
            this.pictureBoxDadoNumero1Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero1Cuarto.Name = "pictureBoxDadoNumero1Cuarto";
            this.pictureBoxDadoNumero1Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero1Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero1Cuarto.TabIndex = 19;
            this.pictureBoxDadoNumero1Cuarto.TabStop = false;
            this.pictureBoxDadoNumero1Cuarto.Visible = false;
            // 
            // pictureBoxDadoNumero2Cuarto
            // 
            this.pictureBoxDadoNumero2Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_2;
            this.pictureBoxDadoNumero2Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero2Cuarto.Name = "pictureBoxDadoNumero2Cuarto";
            this.pictureBoxDadoNumero2Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero2Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero2Cuarto.TabIndex = 20;
            this.pictureBoxDadoNumero2Cuarto.TabStop = false;
            this.pictureBoxDadoNumero2Cuarto.Visible = false;
            // 
            // pictureBoxDadoNumero3Cuarto
            // 
            this.pictureBoxDadoNumero3Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_3;
            this.pictureBoxDadoNumero3Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero3Cuarto.Name = "pictureBoxDadoNumero3Cuarto";
            this.pictureBoxDadoNumero3Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero3Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero3Cuarto.TabIndex = 21;
            this.pictureBoxDadoNumero3Cuarto.TabStop = false;
            this.pictureBoxDadoNumero3Cuarto.Visible = false;
            // 
            // pictureBoxDadoNumero4Cuarto
            // 
            this.pictureBoxDadoNumero4Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_4;
            this.pictureBoxDadoNumero4Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero4Cuarto.Name = "pictureBoxDadoNumero4Cuarto";
            this.pictureBoxDadoNumero4Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero4Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero4Cuarto.TabIndex = 22;
            this.pictureBoxDadoNumero4Cuarto.TabStop = false;
            this.pictureBoxDadoNumero4Cuarto.Visible = false;
            // 
            // pictureBoxDadoNumero5Cuarto
            // 
            this.pictureBoxDadoNumero5Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_5;
            this.pictureBoxDadoNumero5Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero5Cuarto.Name = "pictureBoxDadoNumero5Cuarto";
            this.pictureBoxDadoNumero5Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero5Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero5Cuarto.TabIndex = 23;
            this.pictureBoxDadoNumero5Cuarto.TabStop = false;
            this.pictureBoxDadoNumero5Cuarto.Visible = false;
            // 
            // pictureBoxDadoNumero6Cuarto
            // 
            this.pictureBoxDadoNumero6Cuarto.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.dado_numero_6;
            this.pictureBoxDadoNumero6Cuarto.Location = new System.Drawing.Point(193, 117);
            this.pictureBoxDadoNumero6Cuarto.Name = "pictureBoxDadoNumero6Cuarto";
            this.pictureBoxDadoNumero6Cuarto.Size = new System.Drawing.Size(54, 45);
            this.pictureBoxDadoNumero6Cuarto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDadoNumero6Cuarto.TabIndex = 24;
            this.pictureBoxDadoNumero6Cuarto.TabStop = false;
            this.pictureBoxDadoNumero6Cuarto.Visible = false;
            // 
            // Ejercicio8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBoxDadoNumero6Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero5Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero4Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero3Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero2Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero1Cuarto);
            this.Controls.Add(this.pictureBoxDadoNumero6Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero5Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero4Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero3Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero2Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero1Tercero);
            this.Controls.Add(this.pictureBoxDadoNumero6Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero5Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero4Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero3Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero2Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero1Segundo);
            this.Controls.Add(this.pictureBoxDadoNumero6);
            this.Controls.Add(this.pictureBoxDadoNumero5);
            this.Controls.Add(this.btnPull);
            this.Controls.Add(this.pictureBoxDadoNumero4);
            this.Controls.Add(this.pictureBoxDadoNumero3);
            this.Controls.Add(this.pictureBoxDadoNumero2);
            this.Controls.Add(this.pictureBoxDadoNumero1);
            this.Name = "Ejercicio8";
            this.Text = "Ejercicio8";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Segundo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Tercero)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero1Cuarto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero2Cuarto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero3Cuarto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero4Cuarto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero5Cuarto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDadoNumero6Cuarto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxDadoNumero1;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero2;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero3;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero4;
        private System.Windows.Forms.Button btnPull;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero5;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero6;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero1Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero2Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero3Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero4Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero5Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero6Segundo;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero1Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero2Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero3Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero4Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero5Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero6Tercero;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero1Cuarto;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero2Cuarto;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero3Cuarto;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero4Cuarto;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero5Cuarto;
        private System.Windows.Forms.PictureBox pictureBoxDadoNumero6Cuarto;
    }
}