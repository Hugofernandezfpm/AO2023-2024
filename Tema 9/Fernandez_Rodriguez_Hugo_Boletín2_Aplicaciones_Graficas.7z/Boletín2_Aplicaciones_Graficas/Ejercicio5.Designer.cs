﻿namespace Boletín2_Aplicaciones_Graficas
{
    partial class Ejercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBoxNombreDelEmpleado = new System.Windows.Forms.TextBox();
            this.comboBoxEligeElTurno = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.listBoxTurnoDeMañana = new System.Windows.Forms.ListBox();
            this.listBoxTurnoDeNoche = new System.Windows.Forms.ListBox();
            this.txtBoxTotalMañana = new System.Windows.Forms.TextBox();
            this.txtBoxTotalNoche = new System.Windows.Forms.TextBox();
            this.btnUnoALaDerecha = new System.Windows.Forms.Button();
            this.btnTodoALaDerecha = new System.Windows.Forms.Button();
            this.btnUnoALaIzquierda = new System.Windows.Forms.Button();
            this.btnTodoALaIzquierda = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre del Empleado:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Elige el Turno";
            // 
            // txtBoxNombreDelEmpleado
            // 
            this.txtBoxNombreDelEmpleado.Location = new System.Drawing.Point(141, 18);
            this.txtBoxNombreDelEmpleado.Name = "txtBoxNombreDelEmpleado";
            this.txtBoxNombreDelEmpleado.Size = new System.Drawing.Size(207, 20);
            this.txtBoxNombreDelEmpleado.TabIndex = 2;
            // 
            // comboBoxEligeElTurno
            // 
            this.comboBoxEligeElTurno.FormattingEnabled = true;
            this.comboBoxEligeElTurno.Items.AddRange(new object[] {
            "Turno de mañana",
            "Turno de noche"});
            this.comboBoxEligeElTurno.Location = new System.Drawing.Point(141, 53);
            this.comboBoxEligeElTurno.Name = "comboBoxEligeElTurno";
            this.comboBoxEligeElTurno.Size = new System.Drawing.Size(207, 21);
            this.comboBoxEligeElTurno.TabIndex = 4;
            this.comboBoxEligeElTurno.SelectedIndexChanged += new System.EventHandler(this.comboBoxEligeElTurno_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Turno de Mañana:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(273, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Turno de Noche:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 235);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Total Mañana:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(273, 235);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Total Noche:";
            // 
            // listBoxTurnoDeMañana
            // 
            this.listBoxTurnoDeMañana.FormattingEnabled = true;
            this.listBoxTurnoDeMañana.Location = new System.Drawing.Point(15, 101);
            this.listBoxTurnoDeMañana.Name = "listBoxTurnoDeMañana";
            this.listBoxTurnoDeMañana.Size = new System.Drawing.Size(120, 121);
            this.listBoxTurnoDeMañana.TabIndex = 9;
            this.listBoxTurnoDeMañana.SelectedIndexChanged += new System.EventHandler(this.listBoxTurnoDeMañana_SelectedIndexChanged);
            // 
            // listBoxTurnoDeNoche
            // 
            this.listBoxTurnoDeNoche.FormattingEnabled = true;
            this.listBoxTurnoDeNoche.Location = new System.Drawing.Point(276, 101);
            this.listBoxTurnoDeNoche.Name = "listBoxTurnoDeNoche";
            this.listBoxTurnoDeNoche.Size = new System.Drawing.Size(123, 121);
            this.listBoxTurnoDeNoche.TabIndex = 10;
            // 
            // txtBoxTotalMañana
            // 
            this.txtBoxTotalMañana.Location = new System.Drawing.Point(103, 232);
            this.txtBoxTotalMañana.Name = "txtBoxTotalMañana";
            this.txtBoxTotalMañana.Size = new System.Drawing.Size(32, 20);
            this.txtBoxTotalMañana.TabIndex = 11;
            // 
            // txtBoxTotalNoche
            // 
            this.txtBoxTotalNoche.Location = new System.Drawing.Point(368, 232);
            this.txtBoxTotalNoche.Name = "txtBoxTotalNoche";
            this.txtBoxTotalNoche.Size = new System.Drawing.Size(31, 20);
            this.txtBoxTotalNoche.TabIndex = 12;
            // 
            // btnUnoALaDerecha
            // 
            this.btnUnoALaDerecha.Location = new System.Drawing.Point(169, 101);
            this.btnUnoALaDerecha.Name = "btnUnoALaDerecha";
            this.btnUnoALaDerecha.Size = new System.Drawing.Size(75, 23);
            this.btnUnoALaDerecha.TabIndex = 13;
            this.btnUnoALaDerecha.Text = ">";
            this.btnUnoALaDerecha.UseVisualStyleBackColor = true;
            this.btnUnoALaDerecha.Click += new System.EventHandler(this.btnUnoALaDerecha_Click);
            // 
            // btnTodoALaDerecha
            // 
            this.btnTodoALaDerecha.Location = new System.Drawing.Point(169, 130);
            this.btnTodoALaDerecha.Name = "btnTodoALaDerecha";
            this.btnTodoALaDerecha.Size = new System.Drawing.Size(75, 23);
            this.btnTodoALaDerecha.TabIndex = 14;
            this.btnTodoALaDerecha.Text = ">>";
            this.btnTodoALaDerecha.UseVisualStyleBackColor = true;
            this.btnTodoALaDerecha.Click += new System.EventHandler(this.btnTodoALaDerecha_Click);
            // 
            // btnUnoALaIzquierda
            // 
            this.btnUnoALaIzquierda.Location = new System.Drawing.Point(169, 159);
            this.btnUnoALaIzquierda.Name = "btnUnoALaIzquierda";
            this.btnUnoALaIzquierda.Size = new System.Drawing.Size(75, 23);
            this.btnUnoALaIzquierda.TabIndex = 15;
            this.btnUnoALaIzquierda.Text = "<";
            this.btnUnoALaIzquierda.UseVisualStyleBackColor = true;
            this.btnUnoALaIzquierda.Click += new System.EventHandler(this.btnUnoALaIzquierda_Click);
            // 
            // btnTodoALaIzquierda
            // 
            this.btnTodoALaIzquierda.Location = new System.Drawing.Point(169, 188);
            this.btnTodoALaIzquierda.Name = "btnTodoALaIzquierda";
            this.btnTodoALaIzquierda.Size = new System.Drawing.Size(75, 23);
            this.btnTodoALaIzquierda.TabIndex = 16;
            this.btnTodoALaIzquierda.Text = "<<";
            this.btnTodoALaIzquierda.UseVisualStyleBackColor = true;
            this.btnTodoALaIzquierda.Click += new System.EventHandler(this.btnTodoALaIzquierda_Click);
            // 
            // Ejercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnTodoALaIzquierda);
            this.Controls.Add(this.btnUnoALaIzquierda);
            this.Controls.Add(this.btnTodoALaDerecha);
            this.Controls.Add(this.btnUnoALaDerecha);
            this.Controls.Add(this.txtBoxTotalNoche);
            this.Controls.Add(this.txtBoxTotalMañana);
            this.Controls.Add(this.listBoxTurnoDeNoche);
            this.Controls.Add(this.listBoxTurnoDeMañana);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBoxEligeElTurno);
            this.Controls.Add(this.txtBoxNombreDelEmpleado);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Ejercicio5";
            this.Text = "Ejercicio5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBoxNombreDelEmpleado;
        private System.Windows.Forms.ComboBox comboBoxEligeElTurno;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBoxTurnoDeMañana;
        private System.Windows.Forms.ListBox listBoxTurnoDeNoche;
        private System.Windows.Forms.TextBox txtBoxTotalMañana;
        private System.Windows.Forms.TextBox txtBoxTotalNoche;
        private System.Windows.Forms.Button btnUnoALaDerecha;
        private System.Windows.Forms.Button btnTodoALaDerecha;
        private System.Windows.Forms.Button btnUnoALaIzquierda;
        private System.Windows.Forms.Button btnTodoALaIzquierda;
    }
}