﻿namespace Boletín2_Aplicaciones_Graficas
{
    partial class Ejercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtBoxTotal = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.checkBoxLaserJetX = new System.Windows.Forms.CheckBox();
            this.checkBoxBigNotebook = new System.Windows.Forms.CheckBox();
            this.checkBoxSmartDesktop = new System.Windows.Forms.CheckBox();
            this.checkBoxHDDigicam = new System.Windows.Forms.CheckBox();
            this.checkBoxHiTechMP4 = new System.Windows.Forms.CheckBox();
            this.checkBoxADSLModem = new System.Windows.Forms.CheckBox();
            this.numericUpDownLasertJetX = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownBigNotebook = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownSmartDesktop = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownHDDigicam = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownHiTechMP4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownADSLModem = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLasertJetX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBigNotebook)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSmartDesktop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHDDigicam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHiTechMP4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownADSLModem)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(46, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "LaserJet X  $100";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Big Notebook";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(46, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Smart Desktop";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(285, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "HD Digicam";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(285, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "HiTech MP4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(285, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "ADSL Modem";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(124, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "$100";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(124, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(31, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "$500";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(124, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "$200";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(364, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(25, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "$80";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(364, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "$300";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(364, 81);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "$150";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 153);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(40, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Total =";
            // 
            // txtBoxTotal
            // 
            this.txtBoxTotal.Location = new System.Drawing.Point(58, 150);
            this.txtBoxTotal.Multiline = true;
            this.txtBoxTotal.Name = "txtBoxTotal";
            this.txtBoxTotal.Size = new System.Drawing.Size(65, 30);
            this.txtBoxTotal.TabIndex = 13;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(274, 150);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(75, 23);
            this.btnCalcular.TabIndex = 14;
            this.btnCalcular.Text = "Calculate";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(367, 150);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Text = "Cancel";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // checkBoxLaserJetX
            // 
            this.checkBoxLaserJetX.AutoSize = true;
            this.checkBoxLaserJetX.Location = new System.Drawing.Point(161, 9);
            this.checkBoxLaserJetX.Name = "checkBoxLaserJetX";
            this.checkBoxLaserJetX.Size = new System.Drawing.Size(15, 14);
            this.checkBoxLaserJetX.TabIndex = 16;
            this.checkBoxLaserJetX.UseVisualStyleBackColor = true;
            // 
            // checkBoxBigNotebook
            // 
            this.checkBoxBigNotebook.AutoSize = true;
            this.checkBoxBigNotebook.Location = new System.Drawing.Point(161, 41);
            this.checkBoxBigNotebook.Name = "checkBoxBigNotebook";
            this.checkBoxBigNotebook.Size = new System.Drawing.Size(15, 14);
            this.checkBoxBigNotebook.TabIndex = 17;
            this.checkBoxBigNotebook.UseVisualStyleBackColor = true;
            // 
            // checkBoxSmartDesktop
            // 
            this.checkBoxSmartDesktop.AutoSize = true;
            this.checkBoxSmartDesktop.Location = new System.Drawing.Point(161, 80);
            this.checkBoxSmartDesktop.Name = "checkBoxSmartDesktop";
            this.checkBoxSmartDesktop.Size = new System.Drawing.Size(15, 14);
            this.checkBoxSmartDesktop.TabIndex = 18;
            this.checkBoxSmartDesktop.UseVisualStyleBackColor = true;
            // 
            // checkBoxHDDigicam
            // 
            this.checkBoxHDDigicam.AutoSize = true;
            this.checkBoxHDDigicam.Location = new System.Drawing.Point(401, 9);
            this.checkBoxHDDigicam.Name = "checkBoxHDDigicam";
            this.checkBoxHDDigicam.Size = new System.Drawing.Size(15, 14);
            this.checkBoxHDDigicam.TabIndex = 19;
            this.checkBoxHDDigicam.UseVisualStyleBackColor = true;
            // 
            // checkBoxHiTechMP4
            // 
            this.checkBoxHiTechMP4.AutoSize = true;
            this.checkBoxHiTechMP4.Location = new System.Drawing.Point(401, 42);
            this.checkBoxHiTechMP4.Name = "checkBoxHiTechMP4";
            this.checkBoxHiTechMP4.Size = new System.Drawing.Size(15, 14);
            this.checkBoxHiTechMP4.TabIndex = 20;
            this.checkBoxHiTechMP4.UseVisualStyleBackColor = true;
            // 
            // checkBoxADSLModem
            // 
            this.checkBoxADSLModem.AutoSize = true;
            this.checkBoxADSLModem.Location = new System.Drawing.Point(401, 81);
            this.checkBoxADSLModem.Name = "checkBoxADSLModem";
            this.checkBoxADSLModem.Size = new System.Drawing.Size(15, 14);
            this.checkBoxADSLModem.TabIndex = 21;
            this.checkBoxADSLModem.UseVisualStyleBackColor = true;
            // 
            // numericUpDownLasertJetX
            // 
            this.numericUpDownLasertJetX.Location = new System.Drawing.Point(182, 7);
            this.numericUpDownLasertJetX.Name = "numericUpDownLasertJetX";
            this.numericUpDownLasertJetX.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownLasertJetX.TabIndex = 22;
            // 
            // numericUpDownBigNotebook
            // 
            this.numericUpDownBigNotebook.Location = new System.Drawing.Point(182, 36);
            this.numericUpDownBigNotebook.Name = "numericUpDownBigNotebook";
            this.numericUpDownBigNotebook.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownBigNotebook.TabIndex = 23;
            // 
            // numericUpDownSmartDesktop
            // 
            this.numericUpDownSmartDesktop.Location = new System.Drawing.Point(182, 75);
            this.numericUpDownSmartDesktop.Name = "numericUpDownSmartDesktop";
            this.numericUpDownSmartDesktop.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownSmartDesktop.TabIndex = 24;
            // 
            // numericUpDownHDDigicam
            // 
            this.numericUpDownHDDigicam.Location = new System.Drawing.Point(422, 7);
            this.numericUpDownHDDigicam.Name = "numericUpDownHDDigicam";
            this.numericUpDownHDDigicam.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownHDDigicam.TabIndex = 25;
            // 
            // numericUpDownHiTechMP4
            // 
            this.numericUpDownHiTechMP4.Location = new System.Drawing.Point(422, 39);
            this.numericUpDownHiTechMP4.Name = "numericUpDownHiTechMP4";
            this.numericUpDownHiTechMP4.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownHiTechMP4.TabIndex = 26;
            // 
            // numericUpDownADSLModem
            // 
            this.numericUpDownADSLModem.Location = new System.Drawing.Point(422, 79);
            this.numericUpDownADSLModem.Name = "numericUpDownADSLModem";
            this.numericUpDownADSLModem.Size = new System.Drawing.Size(39, 20);
            this.numericUpDownADSLModem.TabIndex = 27;
            // 
            // Ejercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numericUpDownADSLModem);
            this.Controls.Add(this.numericUpDownHiTechMP4);
            this.Controls.Add(this.numericUpDownHDDigicam);
            this.Controls.Add(this.numericUpDownSmartDesktop);
            this.Controls.Add(this.numericUpDownBigNotebook);
            this.Controls.Add(this.numericUpDownLasertJetX);
            this.Controls.Add(this.checkBoxADSLModem);
            this.Controls.Add(this.checkBoxHiTechMP4);
            this.Controls.Add(this.checkBoxHDDigicam);
            this.Controls.Add(this.checkBoxSmartDesktop);
            this.Controls.Add(this.checkBoxBigNotebook);
            this.Controls.Add(this.checkBoxLaserJetX);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtBoxTotal);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Ejercicio1";
            this.Text = "Ejercicio1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownLasertJetX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownBigNotebook)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSmartDesktop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHDDigicam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHiTechMP4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownADSLModem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtBoxTotal;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.CheckBox checkBoxLaserJetX;
        private System.Windows.Forms.CheckBox checkBoxBigNotebook;
        private System.Windows.Forms.CheckBox checkBoxSmartDesktop;
        private System.Windows.Forms.CheckBox checkBoxHDDigicam;
        private System.Windows.Forms.CheckBox checkBoxHiTechMP4;
        private System.Windows.Forms.CheckBox checkBoxADSLModem;
        private System.Windows.Forms.NumericUpDown numericUpDownLasertJetX;
        private System.Windows.Forms.NumericUpDown numericUpDownBigNotebook;
        private System.Windows.Forms.NumericUpDown numericUpDownSmartDesktop;
        private System.Windows.Forms.NumericUpDown numericUpDownHDDigicam;
        private System.Windows.Forms.NumericUpDown numericUpDownHiTechMP4;
        private System.Windows.Forms.NumericUpDown numericUpDownADSLModem;
    }
}