﻿namespace Boletín2_Aplicaciones_Graficas
{
    partial class Ejercicio9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radioBtnCrema = new System.Windows.Forms.RadioButton();
            this.radioBtnEnsalada = new System.Windows.Forms.RadioButton();
            this.radioBtnEmpanada = new System.Windows.Forms.RadioButton();
            this.radioBtnPescado = new System.Windows.Forms.RadioButton();
            this.radioBtnCarne = new System.Windows.Forms.RadioButton();
            this.radioBtnPasta = new System.Windows.Forms.RadioButton();
            this.radioBtnAgua = new System.Windows.Forms.RadioButton();
            this.radioBtnRefresco = new System.Windows.Forms.RadioButton();
            this.radioBtnVino = new System.Windows.Forms.RadioButton();
            this.radioBtnPostre = new System.Windows.Forms.RadioButton();
            this.radioBtnCafe = new System.Windows.Forms.RadioButton();
            this.comboBoxPrimerPlato = new System.Windows.Forms.ComboBox();
            this.comboBoxSegundoPlato = new System.Windows.Forms.ComboBox();
            this.comboBoxPostre = new System.Windows.Forms.ComboBox();
            this.comboBoxCafe = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtBoxPrecioPrimerPlato = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtBoxPrecioSegundoPlato = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtBoxPrecioBebida = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxPrecioPostreOCafe = new System.Windows.Forms.TextBox();
            this.btnCalcularCuenta = new System.Windows.Forms.Button();
            this.txtBoxPrecioSinIva = new System.Windows.Forms.TextBox();
            this.txtBoxPrecioConIva = new System.Windows.Forms.TextBox();
            this.txtBoxCantidadDada = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtBoxTotalADevolver = new System.Windows.Forms.TextBox();
            this.pictureBoxPostre = new System.Windows.Forms.PictureBox();
            this.pictureBoxCafe = new System.Windows.Forms.PictureBox();
            this.pictureBoxVino = new System.Windows.Forms.PictureBox();
            this.pictureBoxRefresco = new System.Windows.Forms.PictureBox();
            this.pictureBoxAgua = new System.Windows.Forms.PictureBox();
            this.pictureBoxPastas = new System.Windows.Forms.PictureBox();
            this.pictureBoxCarnes = new System.Windows.Forms.PictureBox();
            this.pictureBoxPescado = new System.Windows.Forms.PictureBox();
            this.pictureBoxEmpanadas = new System.Windows.Forms.PictureBox();
            this.pictureBoxEnsaladas = new System.Windows.Forms.PictureBox();
            this.pictureBoxCremas = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPostre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCafe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVino)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresco)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAgua)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPastas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCarnes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPescado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEmpanadas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnsaladas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCremas)).BeginInit();
            this.SuspendLayout();
            // 
            // radioBtnCrema
            // 
            this.radioBtnCrema.AutoSize = true;
            this.radioBtnCrema.Location = new System.Drawing.Point(100, 45);
            this.radioBtnCrema.Name = "radioBtnCrema";
            this.radioBtnCrema.Size = new System.Drawing.Size(55, 17);
            this.radioBtnCrema.TabIndex = 2;
            this.radioBtnCrema.TabStop = true;
            this.radioBtnCrema.Text = "Crema";
            this.radioBtnCrema.UseVisualStyleBackColor = true;
            this.radioBtnCrema.CheckedChanged += new System.EventHandler(this.radioBtnCrema_CheckedChanged);
            // 
            // radioBtnEnsalada
            // 
            this.radioBtnEnsalada.AutoSize = true;
            this.radioBtnEnsalada.Location = new System.Drawing.Point(100, 78);
            this.radioBtnEnsalada.Name = "radioBtnEnsalada";
            this.radioBtnEnsalada.Size = new System.Drawing.Size(69, 17);
            this.radioBtnEnsalada.TabIndex = 3;
            this.radioBtnEnsalada.TabStop = true;
            this.radioBtnEnsalada.Text = "Ensalada";
            this.radioBtnEnsalada.UseVisualStyleBackColor = true;
            this.radioBtnEnsalada.CheckedChanged += new System.EventHandler(this.radioBtnEnsalada_CheckedChanged);
            // 
            // radioBtnEmpanada
            // 
            this.radioBtnEmpanada.AutoSize = true;
            this.radioBtnEmpanada.Location = new System.Drawing.Point(100, 110);
            this.radioBtnEmpanada.Name = "radioBtnEmpanada";
            this.radioBtnEmpanada.Size = new System.Drawing.Size(76, 17);
            this.radioBtnEmpanada.TabIndex = 4;
            this.radioBtnEmpanada.TabStop = true;
            this.radioBtnEmpanada.Text = "Empanada";
            this.radioBtnEmpanada.UseVisualStyleBackColor = true;
            this.radioBtnEmpanada.CheckedChanged += new System.EventHandler(this.radioBtnEmpanada_CheckedChanged);
            // 
            // radioBtnPescado
            // 
            this.radioBtnPescado.AutoSize = true;
            this.radioBtnPescado.Location = new System.Drawing.Point(9, 45);
            this.radioBtnPescado.Name = "radioBtnPescado";
            this.radioBtnPescado.Size = new System.Drawing.Size(67, 17);
            this.radioBtnPescado.TabIndex = 5;
            this.radioBtnPescado.TabStop = true;
            this.radioBtnPescado.Text = "Pescado";
            this.radioBtnPescado.UseVisualStyleBackColor = true;
            this.radioBtnPescado.CheckedChanged += new System.EventHandler(this.radioBtnPescado_CheckedChanged);
            // 
            // radioBtnCarne
            // 
            this.radioBtnCarne.AutoSize = true;
            this.radioBtnCarne.Location = new System.Drawing.Point(12, 78);
            this.radioBtnCarne.Name = "radioBtnCarne";
            this.radioBtnCarne.Size = new System.Drawing.Size(53, 17);
            this.radioBtnCarne.TabIndex = 6;
            this.radioBtnCarne.TabStop = true;
            this.radioBtnCarne.Text = "Carne";
            this.radioBtnCarne.UseVisualStyleBackColor = true;
            this.radioBtnCarne.CheckedChanged += new System.EventHandler(this.radioBtnCarne_CheckedChanged);
            // 
            // radioBtnPasta
            // 
            this.radioBtnPasta.AutoSize = true;
            this.radioBtnPasta.Location = new System.Drawing.Point(13, 110);
            this.radioBtnPasta.Name = "radioBtnPasta";
            this.radioBtnPasta.Size = new System.Drawing.Size(52, 17);
            this.radioBtnPasta.TabIndex = 7;
            this.radioBtnPasta.TabStop = true;
            this.radioBtnPasta.Text = "Pasta";
            this.radioBtnPasta.UseVisualStyleBackColor = true;
            this.radioBtnPasta.CheckedChanged += new System.EventHandler(this.radioBtnPasta_CheckedChanged);
            // 
            // radioBtnAgua
            // 
            this.radioBtnAgua.AutoSize = true;
            this.radioBtnAgua.Location = new System.Drawing.Point(15, 19);
            this.radioBtnAgua.Name = "radioBtnAgua";
            this.radioBtnAgua.Size = new System.Drawing.Size(50, 17);
            this.radioBtnAgua.TabIndex = 8;
            this.radioBtnAgua.TabStop = true;
            this.radioBtnAgua.Text = "Agua";
            this.radioBtnAgua.UseVisualStyleBackColor = true;
            this.radioBtnAgua.CheckedChanged += new System.EventHandler(this.radioBtnAgua_CheckedChanged);
            // 
            // radioBtnRefresco
            // 
            this.radioBtnRefresco.AutoSize = true;
            this.radioBtnRefresco.Location = new System.Drawing.Point(15, 42);
            this.radioBtnRefresco.Name = "radioBtnRefresco";
            this.radioBtnRefresco.Size = new System.Drawing.Size(68, 17);
            this.radioBtnRefresco.TabIndex = 9;
            this.radioBtnRefresco.TabStop = true;
            this.radioBtnRefresco.Text = "Refresco";
            this.radioBtnRefresco.UseVisualStyleBackColor = true;
            this.radioBtnRefresco.CheckedChanged += new System.EventHandler(this.radioBtnRefresco_CheckedChanged);
            // 
            // radioBtnVino
            // 
            this.radioBtnVino.AutoSize = true;
            this.radioBtnVino.Location = new System.Drawing.Point(15, 61);
            this.radioBtnVino.Name = "radioBtnVino";
            this.radioBtnVino.Size = new System.Drawing.Size(46, 17);
            this.radioBtnVino.TabIndex = 10;
            this.radioBtnVino.TabStop = true;
            this.radioBtnVino.Text = "Vino";
            this.radioBtnVino.UseVisualStyleBackColor = true;
            this.radioBtnVino.CheckedChanged += new System.EventHandler(this.radioBtnVino_CheckedChanged);
            // 
            // radioBtnPostre
            // 
            this.radioBtnPostre.AutoSize = true;
            this.radioBtnPostre.Location = new System.Drawing.Point(12, 21);
            this.radioBtnPostre.Name = "radioBtnPostre";
            this.radioBtnPostre.Size = new System.Drawing.Size(55, 17);
            this.radioBtnPostre.TabIndex = 11;
            this.radioBtnPostre.TabStop = true;
            this.radioBtnPostre.Text = "Postre";
            this.radioBtnPostre.UseVisualStyleBackColor = true;
            this.radioBtnPostre.CheckedChanged += new System.EventHandler(this.radioBtnPostre_CheckedChanged);
            // 
            // radioBtnCafe
            // 
            this.radioBtnCafe.AutoSize = true;
            this.radioBtnCafe.Location = new System.Drawing.Point(12, 71);
            this.radioBtnCafe.Name = "radioBtnCafe";
            this.radioBtnCafe.Size = new System.Drawing.Size(47, 17);
            this.radioBtnCafe.TabIndex = 12;
            this.radioBtnCafe.TabStop = true;
            this.radioBtnCafe.Text = "Café";
            this.radioBtnCafe.UseVisualStyleBackColor = true;
            this.radioBtnCafe.CheckedChanged += new System.EventHandler(this.radioBtnCafe_CheckedChanged);
            // 
            // comboBoxPrimerPlato
            // 
            this.comboBoxPrimerPlato.FormattingEnabled = true;
            this.comboBoxPrimerPlato.Location = new System.Drawing.Point(100, 135);
            this.comboBoxPrimerPlato.Name = "comboBoxPrimerPlato";
            this.comboBoxPrimerPlato.Size = new System.Drawing.Size(104, 21);
            this.comboBoxPrimerPlato.TabIndex = 14;
            this.comboBoxPrimerPlato.SelectedIndexChanged += new System.EventHandler(this.comboBoxPrimerPlato_SelectedIndexChanged);
            // 
            // comboBoxSegundoPlato
            // 
            this.comboBoxSegundoPlato.FormattingEnabled = true;
            this.comboBoxSegundoPlato.Location = new System.Drawing.Point(6, 135);
            this.comboBoxSegundoPlato.Name = "comboBoxSegundoPlato";
            this.comboBoxSegundoPlato.Size = new System.Drawing.Size(99, 21);
            this.comboBoxSegundoPlato.TabIndex = 15;
            this.comboBoxSegundoPlato.SelectedIndexChanged += new System.EventHandler(this.comboBoxSegundoPlato_SelectedIndexChanged);
            // 
            // comboBoxPostre
            // 
            this.comboBoxPostre.FormattingEnabled = true;
            this.comboBoxPostre.Location = new System.Drawing.Point(12, 44);
            this.comboBoxPostre.Name = "comboBoxPostre";
            this.comboBoxPostre.Size = new System.Drawing.Size(91, 21);
            this.comboBoxPostre.TabIndex = 16;
            this.comboBoxPostre.SelectedIndexChanged += new System.EventHandler(this.comboBoxPostre_SelectedIndexChanged);
            // 
            // comboBoxCafe
            // 
            this.comboBoxCafe.FormattingEnabled = true;
            this.comboBoxCafe.Location = new System.Drawing.Point(12, 101);
            this.comboBoxCafe.Name = "comboBoxCafe";
            this.comboBoxCafe.Size = new System.Drawing.Size(91, 21);
            this.comboBoxCafe.TabIndex = 17;
            this.comboBoxCafe.SelectedIndexChanged += new System.EventHandler(this.comboBoxCafe_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBoxEmpanadas);
            this.groupBox1.Controls.Add(this.pictureBoxEnsaladas);
            this.groupBox1.Controls.Add(this.txtBoxPrecioPrimerPlato);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.comboBoxPrimerPlato);
            this.groupBox1.Controls.Add(this.radioBtnEmpanada);
            this.groupBox1.Controls.Add(this.radioBtnEnsalada);
            this.groupBox1.Controls.Add(this.radioBtnCrema);
            this.groupBox1.Controls.Add(this.pictureBoxCremas);
            this.groupBox1.Location = new System.Drawing.Point(5, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 219);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Primer Plato";
            // 
            // txtBoxPrecioPrimerPlato
            // 
            this.txtBoxPrecioPrimerPlato.Location = new System.Drawing.Point(110, 174);
            this.txtBoxPrecioPrimerPlato.Name = "txtBoxPrecioPrimerPlato";
            this.txtBoxPrecioPrimerPlato.Size = new System.Drawing.Size(47, 20);
            this.txtBoxPrecioPrimerPlato.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Precio primer plato:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBoxPastas);
            this.groupBox2.Controls.Add(this.pictureBoxCarnes);
            this.groupBox2.Controls.Add(this.pictureBoxPescado);
            this.groupBox2.Controls.Add(this.txtBoxPrecioSegundoPlato);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBoxSegundoPlato);
            this.groupBox2.Controls.Add(this.radioBtnPasta);
            this.groupBox2.Controls.Add(this.radioBtnCarne);
            this.groupBox2.Controls.Add(this.radioBtnPescado);
            this.groupBox2.Location = new System.Drawing.Point(233, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(186, 219);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Segundo Plato";
            // 
            // txtBoxPrecioSegundoPlato
            // 
            this.txtBoxPrecioSegundoPlato.Location = new System.Drawing.Point(9, 193);
            this.txtBoxPrecioSegundoPlato.Name = "txtBoxPrecioSegundoPlato";
            this.txtBoxPrecioSegundoPlato.Size = new System.Drawing.Size(67, 20);
            this.txtBoxPrecioSegundoPlato.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Precio 2º plato:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.pictureBoxVino);
            this.groupBox3.Controls.Add(this.pictureBoxRefresco);
            this.groupBox3.Controls.Add(this.pictureBoxAgua);
            this.groupBox3.Controls.Add(this.txtBoxPrecioBebida);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.radioBtnVino);
            this.groupBox3.Controls.Add(this.radioBtnRefresco);
            this.groupBox3.Controls.Add(this.radioBtnAgua);
            this.groupBox3.Location = new System.Drawing.Point(422, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(275, 84);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Bebida";
            // 
            // txtBoxPrecioBebida
            // 
            this.txtBoxPrecioBebida.Location = new System.Drawing.Point(89, 42);
            this.txtBoxPrecioBebida.Name = "txtBoxPrecioBebida";
            this.txtBoxPrecioBebida.Size = new System.Drawing.Size(39, 20);
            this.txtBoxPrecioBebida.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(87, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Precio bebida:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.pictureBoxPostre);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.txtBoxPrecioPostreOCafe);
            this.groupBox4.Controls.Add(this.comboBoxPostre);
            this.groupBox4.Controls.Add(this.pictureBoxCafe);
            this.groupBox4.Controls.Add(this.radioBtnCafe);
            this.groupBox4.Controls.Add(this.radioBtnPostre);
            this.groupBox4.Controls.Add(this.comboBoxCafe);
            this.groupBox4.Location = new System.Drawing.Point(425, 95);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(202, 128);
            this.groupBox4.TabIndex = 21;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Postre / Cafe";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(109, 82);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(104, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Precio postre/cafe:";
            // 
            // txtBoxPrecioPostreOCafe
            // 
            this.txtBoxPrecioPostreOCafe.Location = new System.Drawing.Point(107, 79);
            this.txtBoxPrecioPostreOCafe.Name = "txtBoxPrecioPostreOCafe";
            this.txtBoxPrecioPostreOCafe.Size = new System.Drawing.Size(40, 20);
            this.txtBoxPrecioPostreOCafe.TabIndex = 18;
            // 
            // btnCalcularCuenta
            // 
            this.btnCalcularCuenta.Location = new System.Drawing.Point(12, 239);
            this.btnCalcularCuenta.Name = "btnCalcularCuenta";
            this.btnCalcularCuenta.Size = new System.Drawing.Size(75, 43);
            this.btnCalcularCuenta.TabIndex = 22;
            this.btnCalcularCuenta.Text = "Calcular cuenta";
            this.btnCalcularCuenta.UseVisualStyleBackColor = true;
            this.btnCalcularCuenta.Click += new System.EventHandler(this.btnCalcularCuenta_Click);
            // 
            // txtBoxPrecioSinIva
            // 
            this.txtBoxPrecioSinIva.Location = new System.Drawing.Point(133, 262);
            this.txtBoxPrecioSinIva.Name = "txtBoxPrecioSinIva";
            this.txtBoxPrecioSinIva.Size = new System.Drawing.Size(100, 20);
            this.txtBoxPrecioSinIva.TabIndex = 23;
            // 
            // txtBoxPrecioConIva
            // 
            this.txtBoxPrecioConIva.Location = new System.Drawing.Point(246, 262);
            this.txtBoxPrecioConIva.Name = "txtBoxPrecioConIva";
            this.txtBoxPrecioConIva.Size = new System.Drawing.Size(100, 20);
            this.txtBoxPrecioConIva.TabIndex = 24;
            // 
            // txtBoxCantidadDada
            // 
            this.txtBoxCantidadDada.Location = new System.Drawing.Point(352, 262);
            this.txtBoxCantidadDada.Name = "txtBoxCantidadDada";
            this.txtBoxCantidadDada.Size = new System.Drawing.Size(100, 20);
            this.txtBoxCantidadDada.TabIndex = 25;
            this.txtBoxCantidadDada.TextChanged += new System.EventHandler(this.txtBoxCantidadDada_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(139, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(130, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "Precio sin IVA";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(243, 239);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(78, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Precio con IVA";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(349, 239);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 29;
            this.label9.Text = "Cantidad dada";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(455, 239);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "Total a devolver";
            // 
            // txtBoxTotalADevolver
            // 
            this.txtBoxTotalADevolver.Location = new System.Drawing.Point(458, 262);
            this.txtBoxTotalADevolver.Name = "txtBoxTotalADevolver";
            this.txtBoxTotalADevolver.Size = new System.Drawing.Size(100, 20);
            this.txtBoxTotalADevolver.TabIndex = 31;
            // 
            // pictureBoxPostre
            // 
            this.pictureBoxPostre.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.tarta_de_chocolate;
            this.pictureBoxPostre.Location = new System.Drawing.Point(107, 10);
            this.pictureBoxPostre.Name = "pictureBoxPostre";
            this.pictureBoxPostre.Size = new System.Drawing.Size(59, 40);
            this.pictureBoxPostre.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPostre.TabIndex = 22;
            this.pictureBoxPostre.TabStop = false;
            // 
            // pictureBoxCafe
            // 
            this.pictureBoxCafe.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.cafe;
            this.pictureBoxCafe.Location = new System.Drawing.Point(65, 67);
            this.pictureBoxCafe.Name = "pictureBoxCafe";
            this.pictureBoxCafe.Size = new System.Drawing.Size(38, 28);
            this.pictureBoxCafe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCafe.TabIndex = 13;
            this.pictureBoxCafe.TabStop = false;
            // 
            // pictureBoxVino
            // 
            this.pictureBoxVino.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.vino;
            this.pictureBoxVino.Location = new System.Drawing.Point(168, 19);
            this.pictureBoxVino.Name = "pictureBoxVino";
            this.pictureBoxVino.Size = new System.Drawing.Size(74, 59);
            this.pictureBoxVino.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxVino.TabIndex = 34;
            this.pictureBoxVino.TabStop = false;
            this.pictureBoxVino.Visible = false;
            // 
            // pictureBoxRefresco
            // 
            this.pictureBoxRefresco.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.coca_cola;
            this.pictureBoxRefresco.Location = new System.Drawing.Point(168, 19);
            this.pictureBoxRefresco.Name = "pictureBoxRefresco";
            this.pictureBoxRefresco.Size = new System.Drawing.Size(74, 59);
            this.pictureBoxRefresco.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxRefresco.TabIndex = 33;
            this.pictureBoxRefresco.TabStop = false;
            this.pictureBoxRefresco.Visible = false;
            // 
            // pictureBoxAgua
            // 
            this.pictureBoxAgua.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.agua;
            this.pictureBoxAgua.Location = new System.Drawing.Point(168, 19);
            this.pictureBoxAgua.Name = "pictureBoxAgua";
            this.pictureBoxAgua.Size = new System.Drawing.Size(74, 59);
            this.pictureBoxAgua.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAgua.TabIndex = 20;
            this.pictureBoxAgua.TabStop = false;
            this.pictureBoxAgua.Visible = false;
            // 
            // pictureBoxPastas
            // 
            this.pictureBoxPastas.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.pastas;
            this.pictureBoxPastas.Location = new System.Drawing.Point(82, 51);
            this.pictureBoxPastas.Name = "pictureBoxPastas";
            this.pictureBoxPastas.Size = new System.Drawing.Size(98, 78);
            this.pictureBoxPastas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPastas.TabIndex = 21;
            this.pictureBoxPastas.TabStop = false;
            this.pictureBoxPastas.Visible = false;
            // 
            // pictureBoxCarnes
            // 
            this.pictureBoxCarnes.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.carnes;
            this.pictureBoxCarnes.Location = new System.Drawing.Point(82, 49);
            this.pictureBoxCarnes.Name = "pictureBoxCarnes";
            this.pictureBoxCarnes.Size = new System.Drawing.Size(98, 78);
            this.pictureBoxCarnes.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCarnes.TabIndex = 20;
            this.pictureBoxCarnes.TabStop = false;
            this.pictureBoxCarnes.Visible = false;
            // 
            // pictureBoxPescado
            // 
            this.pictureBoxPescado.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.pescados;
            this.pictureBoxPescado.Location = new System.Drawing.Point(82, 49);
            this.pictureBoxPescado.Name = "pictureBoxPescado";
            this.pictureBoxPescado.Size = new System.Drawing.Size(98, 78);
            this.pictureBoxPescado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPescado.TabIndex = 19;
            this.pictureBoxPescado.TabStop = false;
            this.pictureBoxPescado.Visible = false;
            // 
            // pictureBoxEmpanadas
            // 
            this.pictureBoxEmpanadas.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.empanada;
            this.pictureBoxEmpanadas.Location = new System.Drawing.Point(6, 45);
            this.pictureBoxEmpanadas.Name = "pictureBoxEmpanadas";
            this.pictureBoxEmpanadas.Size = new System.Drawing.Size(87, 75);
            this.pictureBoxEmpanadas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEmpanadas.TabIndex = 21;
            this.pictureBoxEmpanadas.TabStop = false;
            this.pictureBoxEmpanadas.Visible = false;
            // 
            // pictureBoxEnsaladas
            // 
            this.pictureBoxEnsaladas.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.ensaladas;
            this.pictureBoxEnsaladas.Location = new System.Drawing.Point(6, 45);
            this.pictureBoxEnsaladas.Name = "pictureBoxEnsaladas";
            this.pictureBoxEnsaladas.Size = new System.Drawing.Size(87, 75);
            this.pictureBoxEnsaladas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEnsaladas.TabIndex = 20;
            this.pictureBoxEnsaladas.TabStop = false;
            this.pictureBoxEnsaladas.Visible = false;
            // 
            // pictureBoxCremas
            // 
            this.pictureBoxCremas.Image = global::Boletín2_Aplicaciones_Graficas.Properties.Resources.cremas;
            this.pictureBoxCremas.Location = new System.Drawing.Point(7, 45);
            this.pictureBoxCremas.Name = "pictureBoxCremas";
            this.pictureBoxCremas.Size = new System.Drawing.Size(87, 75);
            this.pictureBoxCremas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxCremas.TabIndex = 1;
            this.pictureBoxCremas.TabStop = false;
            this.pictureBoxCremas.Visible = false;
            // 
            // Ejercicio9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtBoxTotalADevolver);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtBoxCantidadDada);
            this.Controls.Add(this.txtBoxPrecioConIva);
            this.Controls.Add(this.txtBoxPrecioSinIva);
            this.Controls.Add(this.btnCalcularCuenta);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Ejercicio9";
            this.Text = "Ejercicio9";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPostre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCafe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVino)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRefresco)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAgua)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPastas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCarnes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPescado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEmpanadas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEnsaladas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxCremas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxCremas;
        private System.Windows.Forms.RadioButton radioBtnCrema;
        private System.Windows.Forms.RadioButton radioBtnEnsalada;
        private System.Windows.Forms.RadioButton radioBtnEmpanada;
        private System.Windows.Forms.RadioButton radioBtnPescado;
        private System.Windows.Forms.RadioButton radioBtnCarne;
        private System.Windows.Forms.RadioButton radioBtnPasta;
        private System.Windows.Forms.RadioButton radioBtnAgua;
        private System.Windows.Forms.RadioButton radioBtnRefresco;
        private System.Windows.Forms.RadioButton radioBtnVino;
        private System.Windows.Forms.RadioButton radioBtnPostre;
        private System.Windows.Forms.RadioButton radioBtnCafe;
        private System.Windows.Forms.PictureBox pictureBoxCafe;
        private System.Windows.Forms.ComboBox comboBoxPrimerPlato;
        private System.Windows.Forms.ComboBox comboBoxSegundoPlato;
        private System.Windows.Forms.ComboBox comboBoxPostre;
        private System.Windows.Forms.ComboBox comboBoxCafe;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnCalcularCuenta;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxPrecioPrimerPlato;
        private System.Windows.Forms.TextBox txtBoxPrecioSegundoPlato;
        private System.Windows.Forms.TextBox txtBoxPrecioBebida;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxPrecioPostreOCafe;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBoxPrecioSinIva;
        private System.Windows.Forms.TextBox txtBoxPrecioConIva;
        private System.Windows.Forms.TextBox txtBoxCantidadDada;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtBoxTotalADevolver;
        private System.Windows.Forms.PictureBox pictureBoxPostre;
        private System.Windows.Forms.PictureBox pictureBoxEnsaladas;
        private System.Windows.Forms.PictureBox pictureBoxEmpanadas;
        private System.Windows.Forms.PictureBox pictureBoxPescado;
        private System.Windows.Forms.PictureBox pictureBoxCarnes;
        private System.Windows.Forms.PictureBox pictureBoxPastas;
        private System.Windows.Forms.PictureBox pictureBoxAgua;
        private System.Windows.Forms.PictureBox pictureBoxRefresco;
        private System.Windows.Forms.PictureBox pictureBoxVino;
    }
}