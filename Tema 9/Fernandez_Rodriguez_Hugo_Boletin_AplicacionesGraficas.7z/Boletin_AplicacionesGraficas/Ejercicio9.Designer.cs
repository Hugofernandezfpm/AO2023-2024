﻿namespace Boletin_AplicacionesGraficas
{
    partial class Ejercicio9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxEdadGuardar = new System.Windows.Forms.TextBox();
            this.textBoxApellidoGuardar = new System.Windows.Forms.TextBox();
            this.textBoxNombreGuardar = new System.Windows.Forms.TextBox();
            this.textBoxNombreMostrar = new System.Windows.Forms.TextBox();
            this.textBoxEmailGuardar = new System.Windows.Forms.TextBox();
            this.textBoxEmailMostrar = new System.Windows.Forms.TextBox();
            this.textBoxEdadMostrar = new System.Windows.Forms.TextBox();
            this.textBoxApellidosMostrar = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnGuardarUsuario = new System.Windows.Forms.Button();
            this.btnBuscarUsuario2 = new System.Windows.Forms.Button();
            this.textBoxDNIBuscador2 = new System.Windows.Forms.TextBox();
            this.textDNIGuardar = new System.Windows.Forms.TextBox();
            this.textBoxDNIMostrar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBoxDNIBuscador1 = new System.Windows.Forms.TextBox();
            this.btnBuscarUsuario1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBoxEdadGuardar
            // 
            this.textBoxEdadGuardar.Location = new System.Drawing.Point(115, 85);
            this.textBoxEdadGuardar.Name = "textBoxEdadGuardar";
            this.textBoxEdadGuardar.Size = new System.Drawing.Size(100, 20);
            this.textBoxEdadGuardar.TabIndex = 2;
            // 
            // textBoxApellidoGuardar
            // 
            this.textBoxApellidoGuardar.Location = new System.Drawing.Point(115, 59);
            this.textBoxApellidoGuardar.Name = "textBoxApellidoGuardar";
            this.textBoxApellidoGuardar.Size = new System.Drawing.Size(100, 20);
            this.textBoxApellidoGuardar.TabIndex = 4;
            // 
            // textBoxNombreGuardar
            // 
            this.textBoxNombreGuardar.Location = new System.Drawing.Point(115, 33);
            this.textBoxNombreGuardar.Name = "textBoxNombreGuardar";
            this.textBoxNombreGuardar.Size = new System.Drawing.Size(100, 20);
            this.textBoxNombreGuardar.TabIndex = 6;
            // 
            // textBoxNombreMostrar
            // 
            this.textBoxNombreMostrar.Location = new System.Drawing.Point(75, 28);
            this.textBoxNombreMostrar.Name = "textBoxNombreMostrar";
            this.textBoxNombreMostrar.Size = new System.Drawing.Size(100, 20);
            this.textBoxNombreMostrar.TabIndex = 8;
            // 
            // textBoxEmailGuardar
            // 
            this.textBoxEmailGuardar.Location = new System.Drawing.Point(115, 111);
            this.textBoxEmailGuardar.Name = "textBoxEmailGuardar";
            this.textBoxEmailGuardar.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmailGuardar.TabIndex = 15;
            // 
            // textBoxEmailMostrar
            // 
            this.textBoxEmailMostrar.Location = new System.Drawing.Point(75, 106);
            this.textBoxEmailMostrar.Name = "textBoxEmailMostrar";
            this.textBoxEmailMostrar.Size = new System.Drawing.Size(100, 20);
            this.textBoxEmailMostrar.TabIndex = 17;
            // 
            // textBoxEdadMostrar
            // 
            this.textBoxEdadMostrar.Location = new System.Drawing.Point(75, 80);
            this.textBoxEdadMostrar.Name = "textBoxEdadMostrar";
            this.textBoxEdadMostrar.Size = new System.Drawing.Size(100, 20);
            this.textBoxEdadMostrar.TabIndex = 18;
            // 
            // textBoxApellidosMostrar
            // 
            this.textBoxApellidosMostrar.Location = new System.Drawing.Point(75, 54);
            this.textBoxApellidosMostrar.Name = "textBoxApellidosMostrar";
            this.textBoxApellidosMostrar.Size = new System.Drawing.Size(100, 20);
            this.textBoxApellidosMostrar.TabIndex = 19;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Location = new System.Drawing.Point(133, 180);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(220, 18);
            this.dateTimePicker1.TabIndex = 21;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Gray;
            this.button1.Location = new System.Drawing.Point(42, 162);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "<<";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Gray;
            this.button2.Location = new System.Drawing.Point(147, 162);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(32, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = ">>";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Gray;
            this.button3.Location = new System.Drawing.Point(113, 162);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(28, 23);
            this.button3.TabIndex = 24;
            this.button3.Text = ">";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Gray;
            this.button4.Location = new System.Drawing.Point(79, 162);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(28, 23);
            this.button4.TabIndex = 25;
            this.button4.Text = "<";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // btnGuardarUsuario
            // 
            this.btnGuardarUsuario.BackColor = System.Drawing.Color.Silver;
            this.btnGuardarUsuario.Location = new System.Drawing.Point(64, 225);
            this.btnGuardarUsuario.Name = "btnGuardarUsuario";
            this.btnGuardarUsuario.Size = new System.Drawing.Size(117, 38);
            this.btnGuardarUsuario.TabIndex = 26;
            this.btnGuardarUsuario.Text = "Guardar usuario";
            this.btnGuardarUsuario.UseVisualStyleBackColor = false;
            this.btnGuardarUsuario.Click += new System.EventHandler(this.btnGuardarUsuario_Click);
            // 
            // btnBuscarUsuario2
            // 
            this.btnBuscarUsuario2.BackColor = System.Drawing.Color.Silver;
            this.btnBuscarUsuario2.Location = new System.Drawing.Point(36, 39);
            this.btnBuscarUsuario2.Name = "btnBuscarUsuario2";
            this.btnBuscarUsuario2.Size = new System.Drawing.Size(96, 27);
            this.btnBuscarUsuario2.TabIndex = 27;
            this.btnBuscarUsuario2.Text = "Buscar usuario";
            this.btnBuscarUsuario2.UseVisualStyleBackColor = false;
            this.btnBuscarUsuario2.Click += new System.EventHandler(this.btnBuscarUsuario2_Click);
            // 
            // textBoxDNIBuscador2
            // 
            this.textBoxDNIBuscador2.Location = new System.Drawing.Point(69, 13);
            this.textBoxDNIBuscador2.Name = "textBoxDNIBuscador2";
            this.textBoxDNIBuscador2.Size = new System.Drawing.Size(100, 20);
            this.textBoxDNIBuscador2.TabIndex = 29;
            // 
            // textDNIGuardar
            // 
            this.textDNIGuardar.Location = new System.Drawing.Point(115, 137);
            this.textDNIGuardar.Name = "textDNIGuardar";
            this.textDNIGuardar.Size = new System.Drawing.Size(100, 20);
            this.textDNIGuardar.TabIndex = 31;
            // 
            // textBoxDNIMostrar
            // 
            this.textBoxDNIMostrar.Location = new System.Drawing.Point(75, 136);
            this.textBoxDNIMostrar.Name = "textBoxDNIMostrar";
            this.textBoxDNIMostrar.Size = new System.Drawing.Size(100, 20);
            this.textBoxDNIMostrar.TabIndex = 32;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 13);
            this.label1.TabIndex = 33;
            this.label1.Text = "Nombre";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 13);
            this.label9.TabIndex = 41;
            this.label9.Text = "DNI";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 109);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 42;
            this.label10.Text = "Email";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 83);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 43;
            this.label11.Text = "Edad";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 44;
            this.label12.Text = "Apellidos";
            // 
            // textBoxDNIBuscador1
            // 
            this.textBoxDNIBuscador1.Location = new System.Drawing.Point(79, 13);
            this.textBoxDNIBuscador1.Name = "textBoxDNIBuscador1";
            this.textBoxDNIBuscador1.Size = new System.Drawing.Size(100, 20);
            this.textBoxDNIBuscador1.TabIndex = 49;
            // 
            // btnBuscarUsuario1
            // 
            this.btnBuscarUsuario1.BackColor = System.Drawing.Color.Silver;
            this.btnBuscarUsuario1.Location = new System.Drawing.Point(54, 39);
            this.btnBuscarUsuario1.Name = "btnBuscarUsuario1";
            this.btnBuscarUsuario1.Size = new System.Drawing.Size(96, 27);
            this.btnBuscarUsuario1.TabIndex = 47;
            this.btnBuscarUsuario1.Text = "Buscar usuario";
            this.btnBuscarUsuario1.UseVisualStyleBackColor = false;
            this.btnBuscarUsuario1.Click += new System.EventHandler(this.btnBuscarUsuario1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 50;
            this.label2.Text = "DNI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 51;
            this.label3.Text = "DNI";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(26, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "DNI";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 53;
            this.label5.Text = "Nombre";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(51, 62);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 13);
            this.label6.TabIndex = 54;
            this.label6.Text = "Apellidos";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(53, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 55;
            this.label7.Text = "Edad";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(53, 118);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 56;
            this.label8.Text = "Email";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(0, 180);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 13);
            this.label13.TabIndex = 57;
            this.label13.Text = "Fecha de Nacimiento";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBoxDNIBuscador1);
            this.groupBox1.Controls.Add(this.btnBuscarUsuario1);
            this.groupBox1.Location = new System.Drawing.Point(118, 269);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(194, 83);
            this.groupBox1.TabIndex = 58;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Buscar usuario:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.textBoxDNIBuscador2);
            this.groupBox2.Controls.Add(this.btnBuscarUsuario2);
            this.groupBox2.Location = new System.Drawing.Point(332, 269);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(185, 82);
            this.groupBox2.TabIndex = 59;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Borrar usuario";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.textBoxDNIMostrar);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Controls.Add(this.textBoxApellidosMostrar);
            this.groupBox3.Controls.Add(this.textBoxEdadMostrar);
            this.groupBox3.Controls.Add(this.textBoxEmailMostrar);
            this.groupBox3.Controls.Add(this.textBoxNombreMostrar);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.groupBox3.Location = new System.Drawing.Point(368, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(195, 193);
            this.groupBox3.TabIndex = 60;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Visualizar usuario";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.textDNIGuardar);
            this.groupBox4.Controls.Add(this.dateTimePicker1);
            this.groupBox4.Controls.Add(this.textBoxEmailGuardar);
            this.groupBox4.Controls.Add(this.textBoxNombreGuardar);
            this.groupBox4.Controls.Add(this.textBoxApellidoGuardar);
            this.groupBox4.Controls.Add(this.textBoxEdadGuardar);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox4.Location = new System.Drawing.Point(3, 5);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(359, 209);
            this.groupBox4.TabIndex = 61;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Datos personales";
            // 
            // Ejercicio9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnGuardarUsuario);
            this.Name = "Ejercicio9";
            this.Text = "Ejercicio9";
            this.Load += new System.EventHandler(this.Ejercicio9_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox textBoxEdadGuardar;
        private System.Windows.Forms.TextBox textBoxApellidoGuardar;
        private System.Windows.Forms.TextBox textBoxNombreGuardar;
        private System.Windows.Forms.TextBox textBoxNombreMostrar;
        private System.Windows.Forms.TextBox textBoxEmailGuardar;
        private System.Windows.Forms.TextBox textBoxEmailMostrar;
        private System.Windows.Forms.TextBox textBoxEdadMostrar;
        private System.Windows.Forms.TextBox textBoxApellidosMostrar;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnGuardarUsuario;
        private System.Windows.Forms.Button btnBuscarUsuario2;
        private System.Windows.Forms.TextBox textBoxDNIBuscador2;
        private System.Windows.Forms.TextBox textDNIGuardar;
        private System.Windows.Forms.TextBox textBoxDNIMostrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxDNIBuscador1;
        private System.Windows.Forms.Button btnBuscarUsuario1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
    }
}