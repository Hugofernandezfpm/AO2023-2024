﻿namespace Boletin_AplicacionesGraficas
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.EjerciciosSelecionados = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio4ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio5ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio6ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio7ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio8ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ejercicio9ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.EjerciciosSelecionados});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // EjerciciosSelecionados
            // 
            this.EjerciciosSelecionados.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ejercicio1ToolStripMenuItem,
            this.ejercicio2ToolStripMenuItem,
            this.ejercicio3ToolStripMenuItem,
            this.ejercicio4ToolStripMenuItem,
            this.ejercicio5ToolStripMenuItem,
            this.ejercicio6ToolStripMenuItem,
            this.ejercicio7ToolStripMenuItem,
            this.ejercicio8ToolStripMenuItem,
            this.ejercicio9ToolStripMenuItem});
            this.EjerciciosSelecionados.Name = "EjerciciosSelecionados";
            this.EjerciciosSelecionados.Size = new System.Drawing.Size(68, 20);
            this.EjerciciosSelecionados.Text = "Ejercicios";
            // 
            // ejercicio1ToolStripMenuItem
            // 
            this.ejercicio1ToolStripMenuItem.Name = "ejercicio1ToolStripMenuItem";
            this.ejercicio1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio1ToolStripMenuItem.Text = "Ejercicio1";
            this.ejercicio1ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio1ToolStripMenuItem_Click);
            // 
            // ejercicio2ToolStripMenuItem
            // 
            this.ejercicio2ToolStripMenuItem.Name = "ejercicio2ToolStripMenuItem";
            this.ejercicio2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio2ToolStripMenuItem.Text = "Ejercicio2";
            this.ejercicio2ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio2ToolStripMenuItem_Click);
            // 
            // ejercicio3ToolStripMenuItem
            // 
            this.ejercicio3ToolStripMenuItem.Name = "ejercicio3ToolStripMenuItem";
            this.ejercicio3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio3ToolStripMenuItem.Text = "Ejercicio3";
            this.ejercicio3ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio3ToolStripMenuItem_Click);
            // 
            // ejercicio4ToolStripMenuItem
            // 
            this.ejercicio4ToolStripMenuItem.Name = "ejercicio4ToolStripMenuItem";
            this.ejercicio4ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio4ToolStripMenuItem.Text = "Ejercicio4";
            this.ejercicio4ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio4ToolStripMenuItem_Click);
            // 
            // ejercicio5ToolStripMenuItem
            // 
            this.ejercicio5ToolStripMenuItem.Name = "ejercicio5ToolStripMenuItem";
            this.ejercicio5ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio5ToolStripMenuItem.Text = "Ejercicio5";
            this.ejercicio5ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio5ToolStripMenuItem_Click);
            // 
            // ejercicio6ToolStripMenuItem
            // 
            this.ejercicio6ToolStripMenuItem.Name = "ejercicio6ToolStripMenuItem";
            this.ejercicio6ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio6ToolStripMenuItem.Text = "Ejercicio6";
            this.ejercicio6ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio6ToolStripMenuItem_Click);
            // 
            // ejercicio7ToolStripMenuItem
            // 
            this.ejercicio7ToolStripMenuItem.Name = "ejercicio7ToolStripMenuItem";
            this.ejercicio7ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio7ToolStripMenuItem.Text = "Ejercicio7";
            this.ejercicio7ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio7ToolStripMenuItem_Click);
            // 
            // ejercicio8ToolStripMenuItem
            // 
            this.ejercicio8ToolStripMenuItem.Name = "ejercicio8ToolStripMenuItem";
            this.ejercicio8ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio8ToolStripMenuItem.Text = "Ejercicio8";
            this.ejercicio8ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio8ToolStripMenuItem_Click);
            // 
            // ejercicio9ToolStripMenuItem
            // 
            this.ejercicio9ToolStripMenuItem.Name = "ejercicio9ToolStripMenuItem";
            this.ejercicio9ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.ejercicio9ToolStripMenuItem.Text = "Ejercicio9";
            this.ejercicio9ToolStripMenuItem.Click += new System.EventHandler(this.ejercicio9ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem EjerciciosSelecionados;
        private System.Windows.Forms.ToolStripMenuItem ejercicio1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio4ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio5ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio6ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio7ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio8ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ejercicio9ToolStripMenuItem;
    }
}

