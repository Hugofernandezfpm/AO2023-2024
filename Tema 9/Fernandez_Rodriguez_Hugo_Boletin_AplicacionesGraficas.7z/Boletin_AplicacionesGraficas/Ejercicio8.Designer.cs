﻿namespace Boletin_AplicacionesGraficas
{
    partial class Ejercicio8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNumero1 = new System.Windows.Forms.Button();
            this.textBoxResultado = new System.Windows.Forms.TextBox();
            this.btnNumero0 = new System.Windows.Forms.Button();
            this.btnPunto = new System.Windows.Forms.Button();
            this.btnNumero9 = new System.Windows.Forms.Button();
            this.btnNumero8 = new System.Windows.Forms.Button();
            this.btnNumero7 = new System.Windows.Forms.Button();
            this.btnNumero6 = new System.Windows.Forms.Button();
            this.btnNumero5 = new System.Windows.Forms.Button();
            this.btnNumero4 = new System.Windows.Forms.Button();
            this.btnNumero3 = new System.Windows.Forms.Button();
            this.btnNumero2 = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnMMas = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnRestar = new System.Windows.Forms.Button();
            this.btnPorcentaje = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnSumar = new System.Windows.Forms.Button();
            this.btnIgual = new System.Windows.Forms.Button();
            this.btnBinario = new System.Windows.Forms.Button();
            this.btnSen = new System.Windows.Forms.Button();
            this.btnCos = new System.Windows.Forms.Button();
            this.btnRaiz = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.buttonMS = new System.Windows.Forms.Button();
            this.btnMR = new System.Windows.Forms.Button();
            this.btnMMenos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnNumero1
            // 
            this.btnNumero1.Location = new System.Drawing.Point(111, 197);
            this.btnNumero1.Name = "btnNumero1";
            this.btnNumero1.Size = new System.Drawing.Size(46, 33);
            this.btnNumero1.TabIndex = 15;
            this.btnNumero1.Text = "1";
            this.btnNumero1.UseVisualStyleBackColor = true;
            this.btnNumero1.Click += new System.EventHandler(this.btnNumero1_Click);
            // 
            // textBoxResultado
            // 
            this.textBoxResultado.Location = new System.Drawing.Point(111, 42);
            this.textBoxResultado.Multiline = true;
            this.textBoxResultado.Name = "textBoxResultado";
            this.textBoxResultado.Size = new System.Drawing.Size(433, 67);
            this.textBoxResultado.TabIndex = 14;
            // 
            // btnNumero0
            // 
            this.btnNumero0.Location = new System.Drawing.Point(111, 236);
            this.btnNumero0.Name = "btnNumero0";
            this.btnNumero0.Size = new System.Drawing.Size(98, 33);
            this.btnNumero0.TabIndex = 16;
            this.btnNumero0.Text = "0";
            this.btnNumero0.UseVisualStyleBackColor = true;
            this.btnNumero0.Click += new System.EventHandler(this.btnNumero0_Click);
            // 
            // btnPunto
            // 
            this.btnPunto.Location = new System.Drawing.Point(215, 236);
            this.btnPunto.Name = "btnPunto";
            this.btnPunto.Size = new System.Drawing.Size(46, 33);
            this.btnPunto.TabIndex = 17;
            this.btnPunto.Text = ".";
            this.btnPunto.UseVisualStyleBackColor = true;
            this.btnPunto.Click += new System.EventHandler(this.btnPunto_Click);
            // 
            // btnNumero9
            // 
            this.btnNumero9.Location = new System.Drawing.Point(215, 119);
            this.btnNumero9.Name = "btnNumero9";
            this.btnNumero9.Size = new System.Drawing.Size(46, 33);
            this.btnNumero9.TabIndex = 18;
            this.btnNumero9.Text = "9";
            this.btnNumero9.UseVisualStyleBackColor = true;
            this.btnNumero9.Click += new System.EventHandler(this.btnNumero9_Click);
            // 
            // btnNumero8
            // 
            this.btnNumero8.Location = new System.Drawing.Point(163, 119);
            this.btnNumero8.Name = "btnNumero8";
            this.btnNumero8.Size = new System.Drawing.Size(46, 33);
            this.btnNumero8.TabIndex = 19;
            this.btnNumero8.Text = "8";
            this.btnNumero8.UseVisualStyleBackColor = true;
            this.btnNumero8.Click += new System.EventHandler(this.btnNumero8_Click);
            // 
            // btnNumero7
            // 
            this.btnNumero7.Location = new System.Drawing.Point(111, 119);
            this.btnNumero7.Name = "btnNumero7";
            this.btnNumero7.Size = new System.Drawing.Size(46, 33);
            this.btnNumero7.TabIndex = 20;
            this.btnNumero7.Text = "7";
            this.btnNumero7.UseVisualStyleBackColor = true;
            this.btnNumero7.Click += new System.EventHandler(this.btnNumero7_Click);
            // 
            // btnNumero6
            // 
            this.btnNumero6.Location = new System.Drawing.Point(215, 158);
            this.btnNumero6.Name = "btnNumero6";
            this.btnNumero6.Size = new System.Drawing.Size(46, 33);
            this.btnNumero6.TabIndex = 21;
            this.btnNumero6.Text = "6";
            this.btnNumero6.UseVisualStyleBackColor = true;
            this.btnNumero6.Click += new System.EventHandler(this.btnNumero6_Click);
            // 
            // btnNumero5
            // 
            this.btnNumero5.Location = new System.Drawing.Point(163, 158);
            this.btnNumero5.Name = "btnNumero5";
            this.btnNumero5.Size = new System.Drawing.Size(46, 33);
            this.btnNumero5.TabIndex = 22;
            this.btnNumero5.Text = "5";
            this.btnNumero5.UseVisualStyleBackColor = true;
            this.btnNumero5.Click += new System.EventHandler(this.btnNumero5_Click);
            // 
            // btnNumero4
            // 
            this.btnNumero4.Location = new System.Drawing.Point(111, 158);
            this.btnNumero4.Name = "btnNumero4";
            this.btnNumero4.Size = new System.Drawing.Size(46, 33);
            this.btnNumero4.TabIndex = 23;
            this.btnNumero4.Text = "4";
            this.btnNumero4.UseVisualStyleBackColor = true;
            this.btnNumero4.Click += new System.EventHandler(this.btnNumero4_Click);
            // 
            // btnNumero3
            // 
            this.btnNumero3.Location = new System.Drawing.Point(215, 197);
            this.btnNumero3.Name = "btnNumero3";
            this.btnNumero3.Size = new System.Drawing.Size(46, 33);
            this.btnNumero3.TabIndex = 24;
            this.btnNumero3.Text = "3";
            this.btnNumero3.UseVisualStyleBackColor = true;
            this.btnNumero3.Click += new System.EventHandler(this.btnNumero3_Click);
            // 
            // btnNumero2
            // 
            this.btnNumero2.Location = new System.Drawing.Point(163, 197);
            this.btnNumero2.Name = "btnNumero2";
            this.btnNumero2.Size = new System.Drawing.Size(46, 33);
            this.btnNumero2.TabIndex = 25;
            this.btnNumero2.Text = "2";
            this.btnNumero2.UseVisualStyleBackColor = true;
            this.btnNumero2.Click += new System.EventHandler(this.btnNumero2_Click);
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(319, 119);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(46, 33);
            this.btnC.TabIndex = 26;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnMMas
            // 
            this.btnMMas.Location = new System.Drawing.Point(519, 126);
            this.btnMMas.Name = "btnMMas";
            this.btnMMas.Size = new System.Drawing.Size(46, 19);
            this.btnMMas.TabIndex = 27;
            this.btnMMas.Text = "M+";
            this.btnMMas.UseVisualStyleBackColor = true;
            // 
            // btnCE
            // 
            this.btnCE.Location = new System.Drawing.Point(371, 119);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(46, 33);
            this.btnCE.TabIndex = 28;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = true;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.Location = new System.Drawing.Point(319, 158);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(46, 33);
            this.btnDividir.TabIndex = 29;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.operador);
            // 
            // btnRestar
            // 
            this.btnRestar.Location = new System.Drawing.Point(371, 158);
            this.btnRestar.Name = "btnRestar";
            this.btnRestar.Size = new System.Drawing.Size(46, 33);
            this.btnRestar.TabIndex = 30;
            this.btnRestar.Text = "-";
            this.btnRestar.UseVisualStyleBackColor = true;
            this.btnRestar.Click += new System.EventHandler(this.operador);
            // 
            // btnPorcentaje
            // 
            this.btnPorcentaje.Location = new System.Drawing.Point(371, 236);
            this.btnPorcentaje.Name = "btnPorcentaje";
            this.btnPorcentaje.Size = new System.Drawing.Size(46, 33);
            this.btnPorcentaje.TabIndex = 31;
            this.btnPorcentaje.Text = "%";
            this.btnPorcentaje.UseVisualStyleBackColor = true;
            this.btnPorcentaje.Click += new System.EventHandler(this.operador);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Location = new System.Drawing.Point(319, 197);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(46, 33);
            this.btnMultiplicar.TabIndex = 32;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.operador);
            // 
            // btnSumar
            // 
            this.btnSumar.Location = new System.Drawing.Point(371, 197);
            this.btnSumar.Name = "btnSumar";
            this.btnSumar.Size = new System.Drawing.Size(46, 33);
            this.btnSumar.TabIndex = 33;
            this.btnSumar.Text = "+";
            this.btnSumar.UseVisualStyleBackColor = true;
            this.btnSumar.Click += new System.EventHandler(this.operador);
            // 
            // btnIgual
            // 
            this.btnIgual.Location = new System.Drawing.Point(319, 236);
            this.btnIgual.Name = "btnIgual";
            this.btnIgual.Size = new System.Drawing.Size(46, 33);
            this.btnIgual.TabIndex = 34;
            this.btnIgual.Text = "=";
            this.btnIgual.UseVisualStyleBackColor = true;
            this.btnIgual.Click += new System.EventHandler(this.btnIgual_Click);
            // 
            // btnBinario
            // 
            this.btnBinario.Location = new System.Drawing.Point(519, 176);
            this.btnBinario.Name = "btnBinario";
            this.btnBinario.Size = new System.Drawing.Size(98, 19);
            this.btnBinario.TabIndex = 35;
            this.btnBinario.Text = "Binario";
            this.btnBinario.UseVisualStyleBackColor = true;
            this.btnBinario.Click += new System.EventHandler(this.btnBinario_Click);
            // 
            // btnSen
            // 
            this.btnSen.Location = new System.Drawing.Point(623, 151);
            this.btnSen.Name = "btnSen";
            this.btnSen.Size = new System.Drawing.Size(46, 19);
            this.btnSen.TabIndex = 36;
            this.btnSen.Text = "sen";
            this.btnSen.UseVisualStyleBackColor = true;
            // 
            // btnCos
            // 
            this.btnCos.Location = new System.Drawing.Point(571, 151);
            this.btnCos.Name = "btnCos";
            this.btnCos.Size = new System.Drawing.Size(46, 19);
            this.btnCos.TabIndex = 37;
            this.btnCos.Text = "cos";
            this.btnCos.UseVisualStyleBackColor = true;
            // 
            // btnRaiz
            // 
            this.btnRaiz.Location = new System.Drawing.Point(519, 151);
            this.btnRaiz.Name = "btnRaiz";
            this.btnRaiz.Size = new System.Drawing.Size(46, 19);
            this.btnRaiz.TabIndex = 38;
            this.btnRaiz.Text = "Raiz";
            this.btnRaiz.UseVisualStyleBackColor = true;
            // 
            // buttonMC
            // 
            this.buttonMC.Location = new System.Drawing.Point(623, 101);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(46, 19);
            this.buttonMC.TabIndex = 39;
            this.buttonMC.Text = "MC";
            this.buttonMC.UseVisualStyleBackColor = true;
            // 
            // buttonMS
            // 
            this.buttonMS.Location = new System.Drawing.Point(571, 101);
            this.buttonMS.Name = "buttonMS";
            this.buttonMS.Size = new System.Drawing.Size(46, 19);
            this.buttonMS.TabIndex = 40;
            this.buttonMS.Text = "MS";
            this.buttonMS.UseVisualStyleBackColor = true;
            // 
            // btnMR
            // 
            this.btnMR.Location = new System.Drawing.Point(623, 126);
            this.btnMR.Name = "btnMR";
            this.btnMR.Size = new System.Drawing.Size(46, 19);
            this.btnMR.TabIndex = 41;
            this.btnMR.Text = "MR";
            this.btnMR.UseVisualStyleBackColor = true;
            // 
            // btnMMenos
            // 
            this.btnMMenos.Location = new System.Drawing.Point(571, 126);
            this.btnMMenos.Name = "btnMMenos";
            this.btnMMenos.Size = new System.Drawing.Size(46, 19);
            this.btnMMenos.TabIndex = 42;
            this.btnMMenos.Text = "M-";
            this.btnMMenos.UseVisualStyleBackColor = true;
            // 
            // Ejercicio8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnMMenos);
            this.Controls.Add(this.btnMR);
            this.Controls.Add(this.buttonMS);
            this.Controls.Add(this.buttonMC);
            this.Controls.Add(this.btnRaiz);
            this.Controls.Add(this.btnCos);
            this.Controls.Add(this.btnSen);
            this.Controls.Add(this.btnBinario);
            this.Controls.Add(this.btnIgual);
            this.Controls.Add(this.btnSumar);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnPorcentaje);
            this.Controls.Add(this.btnRestar);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btnMMas);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnNumero2);
            this.Controls.Add(this.btnNumero3);
            this.Controls.Add(this.btnNumero4);
            this.Controls.Add(this.btnNumero5);
            this.Controls.Add(this.btnNumero6);
            this.Controls.Add(this.btnNumero7);
            this.Controls.Add(this.btnNumero8);
            this.Controls.Add(this.btnNumero9);
            this.Controls.Add(this.btnPunto);
            this.Controls.Add(this.btnNumero0);
            this.Controls.Add(this.btnNumero1);
            this.Controls.Add(this.textBoxResultado);
            this.Name = "Ejercicio8";
            this.Text = "Ejercicio8";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNumero1;
        private System.Windows.Forms.TextBox textBoxResultado;
        private System.Windows.Forms.Button btnNumero0;
        private System.Windows.Forms.Button btnPunto;
        private System.Windows.Forms.Button btnNumero9;
        private System.Windows.Forms.Button btnNumero8;
        private System.Windows.Forms.Button btnNumero7;
        private System.Windows.Forms.Button btnNumero6;
        private System.Windows.Forms.Button btnNumero5;
        private System.Windows.Forms.Button btnNumero4;
        private System.Windows.Forms.Button btnNumero3;
        private System.Windows.Forms.Button btnNumero2;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnMMas;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnRestar;
        private System.Windows.Forms.Button btnPorcentaje;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnSumar;
        private System.Windows.Forms.Button btnIgual;
        private System.Windows.Forms.Button btnBinario;
        private System.Windows.Forms.Button btnSen;
        private System.Windows.Forms.Button btnCos;
        private System.Windows.Forms.Button btnRaiz;
        private System.Windows.Forms.Button buttonMC;
        private System.Windows.Forms.Button buttonMS;
        private System.Windows.Forms.Button btnMR;
        private System.Windows.Forms.Button btnMMenos;
    }
}