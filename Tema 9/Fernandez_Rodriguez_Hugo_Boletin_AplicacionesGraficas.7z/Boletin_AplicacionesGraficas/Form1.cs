﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Boletin_AplicacionesGraficas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ejercicio1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio1 ejercicio1 = new Ejercicio1();
            ejercicio1.Show();
        }

        private void ejercicio2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio2 ejercicio2 = new Ejercicio2();
            ejercicio2.Show();
        }

        private void ejercicio3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio3 ejercicio3 = new Ejercicio3();
            ejercicio3.Show();
        }

        private void ejercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio4 ejercicio4 = new Ejercicio4();
            ejercicio4.Show();
        }

        private void ejercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio5 ejercicio5 = new Ejercicio5();
            ejercicio5.Show();
        }

        private void ejercicio6ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio6 ejercicio6 = new Ejercicio6();
            ejercicio6.Show();
        }

        private void ejercicio7ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio7 ejercicio7 = new Ejercicio7();
            ejercicio7.Show();
        }

        private void ejercicio8ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio8 ejercicio8 = new Ejercicio8();
            ejercicio8.Show();
        }

        private void ejercicio9ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //vamos a asignar un evento de click a cada ejercicio 

            Ejercicio9 ejercicio9 = new Ejercicio9();
            ejercicio9.Show();
        }
    }
    }

