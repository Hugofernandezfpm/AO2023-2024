﻿namespace Proyecto_final
{
    partial class Cesta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBoxHPDESKTOP = new System.Windows.Forms.PictureBox();
            this.txtBoxPrecioMovil = new System.Windows.Forms.TextBox();
            this.txtBoxProcesadorMovil = new System.Windows.Forms.TextBox();
            this.txtBoxCamaraMovil = new System.Windows.Forms.TextBox();
            this.txtBoxRAMMovil = new System.Windows.Forms.TextBox();
            this.txtBoxModeloMovil = new System.Windows.Forms.TextBox();
            this.txtBoxMarcaMovil = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtBoxCodigoMovil = new System.Windows.Forms.TextBox();
            this.pictureBoxRealme6i = new System.Windows.Forms.PictureBox();
            this.Precio = new System.Windows.Forms.Label();
            this.txtBoxPrecioOrdenador = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtBoxProcesadorOrdenador = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtBoxSSDoHDDOrdenador = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBoxRAMOrdenador = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtBoxModeloOrdenador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBoxMarcaOrdenador = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBoxCodigoOrdenador = new System.Windows.Forms.TextBox();
            this.btn_Siguiente_Ordenadores = new System.Windows.Forms.Button();
            this.btn_Anterior_Ordenadores = new System.Windows.Forms.Button();
            this.btn_Anterior_Moviles = new System.Windows.Forms.Button();
            this.btn_Siguiente_Moviles = new System.Windows.Forms.Button();
            this.pictureBoxPocox6pro = new System.Windows.Forms.PictureBox();
            this.pictureBoxPocoX6 = new System.Windows.Forms.PictureBox();
            this.pictureBoxRealmeC67 = new System.Windows.Forms.PictureBox();
            this.pictureBoxDELL7010 = new System.Windows.Forms.PictureBox();
            this.pictureBoxVoltier = new System.Windows.Forms.PictureBox();
            this.pictureBoxPCCOM = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHPDESKTOP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRealme6i)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPocox6pro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPocoX6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRealmeC67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDELL7010)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVoltier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPCCOM)).BeginInit();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(410, 254);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 79;
            this.label6.Text = "Precio";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(410, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 78;
            this.label10.Text = "Procesador";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(410, 197);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 76;
            this.label12.Text = "Camara";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(410, 171);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 75;
            this.label13.Text = "RAM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(410, 140);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 74;
            this.label14.Text = "Modelo";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(410, 114);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 73;
            this.label15.Text = "Marca";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(410, 83);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 72;
            this.label16.Text = "Código";
            // 
            // pictureBoxHPDESKTOP
            // 
            this.pictureBoxHPDESKTOP.Image = global::Proyecto_final.Properties.Resources.HP_Desktop_M01_F2052ns;
            this.pictureBoxHPDESKTOP.Location = new System.Drawing.Point(181, 57);
            this.pictureBoxHPDESKTOP.Name = "pictureBoxHPDESKTOP";
            this.pictureBoxHPDESKTOP.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxHPDESKTOP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxHPDESKTOP.TabIndex = 71;
            this.pictureBoxHPDESKTOP.TabStop = false;
            this.pictureBoxHPDESKTOP.Visible = false;
            // 
            // txtBoxPrecioMovil
            // 
            this.txtBoxPrecioMovil.Location = new System.Drawing.Point(481, 251);
            this.txtBoxPrecioMovil.Name = "txtBoxPrecioMovil";
            this.txtBoxPrecioMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxPrecioMovil.TabIndex = 70;
            // 
            // txtBoxProcesadorMovil
            // 
            this.txtBoxProcesadorMovil.Location = new System.Drawing.Point(481, 220);
            this.txtBoxProcesadorMovil.Name = "txtBoxProcesadorMovil";
            this.txtBoxProcesadorMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxProcesadorMovil.TabIndex = 69;
            // 
            // txtBoxCamaraMovil
            // 
            this.txtBoxCamaraMovil.Location = new System.Drawing.Point(481, 194);
            this.txtBoxCamaraMovil.Name = "txtBoxCamaraMovil";
            this.txtBoxCamaraMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxCamaraMovil.TabIndex = 67;
            // 
            // txtBoxRAMMovil
            // 
            this.txtBoxRAMMovil.Location = new System.Drawing.Point(481, 168);
            this.txtBoxRAMMovil.Name = "txtBoxRAMMovil";
            this.txtBoxRAMMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxRAMMovil.TabIndex = 66;
            // 
            // txtBoxModeloMovil
            // 
            this.txtBoxModeloMovil.Location = new System.Drawing.Point(481, 137);
            this.txtBoxModeloMovil.Name = "txtBoxModeloMovil";
            this.txtBoxModeloMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModeloMovil.TabIndex = 65;
            // 
            // txtBoxMarcaMovil
            // 
            this.txtBoxMarcaMovil.Location = new System.Drawing.Point(481, 111);
            this.txtBoxMarcaMovil.Name = "txtBoxMarcaMovil";
            this.txtBoxMarcaMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxMarcaMovil.TabIndex = 64;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(478, 40);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(46, 13);
            this.label18.TabIndex = 63;
            this.label18.Text = "Móviles:";
            // 
            // txtBoxCodigoMovil
            // 
            this.txtBoxCodigoMovil.Location = new System.Drawing.Point(481, 80);
            this.txtBoxCodigoMovil.Name = "txtBoxCodigoMovil";
            this.txtBoxCodigoMovil.Size = new System.Drawing.Size(100, 20);
            this.txtBoxCodigoMovil.TabIndex = 62;
            // 
            // pictureBoxRealme6i
            // 
            this.pictureBoxRealme6i.Image = global::Proyecto_final.Properties.Resources.realme_6i;
            this.pictureBoxRealme6i.Location = new System.Drawing.Point(587, 57);
            this.pictureBoxRealme6i.Name = "pictureBoxRealme6i";
            this.pictureBoxRealme6i.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxRealme6i.TabIndex = 61;
            this.pictureBoxRealme6i.TabStop = false;
            this.pictureBoxRealme6i.Visible = false;
            // 
            // Precio
            // 
            this.Precio.AutoSize = true;
            this.Precio.Location = new System.Drawing.Point(10, 259);
            this.Precio.Name = "Precio";
            this.Precio.Size = new System.Drawing.Size(37, 13);
            this.Precio.TabIndex = 60;
            this.Precio.Text = "Precio";
            // 
            // txtBoxPrecioOrdenador
            // 
            this.txtBoxPrecioOrdenador.Location = new System.Drawing.Point(75, 254);
            this.txtBoxPrecioOrdenador.Name = "txtBoxPrecioOrdenador";
            this.txtBoxPrecioOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxPrecioOrdenador.TabIndex = 59;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 226);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 58;
            this.label7.Text = "Procesador";
            // 
            // txtBoxProcesadorOrdenador
            // 
            this.txtBoxProcesadorOrdenador.Location = new System.Drawing.Point(75, 223);
            this.txtBoxProcesadorOrdenador.Name = "txtBoxProcesadorOrdenador";
            this.txtBoxProcesadorOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxProcesadorOrdenador.TabIndex = 57;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 195);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 54;
            this.label9.Text = "SSD o HDD";
            // 
            // txtBoxSSDoHDDOrdenador
            // 
            this.txtBoxSSDoHDDOrdenador.Location = new System.Drawing.Point(75, 192);
            this.txtBoxSSDoHDDOrdenador.Name = "txtBoxSSDoHDDOrdenador";
            this.txtBoxSSDoHDDOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxSSDoHDDOrdenador.TabIndex = 53;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 52;
            this.label4.Text = "RAM";
            // 
            // txtBoxRAMOrdenador
            // 
            this.txtBoxRAMOrdenador.Location = new System.Drawing.Point(75, 166);
            this.txtBoxRAMOrdenador.Name = "txtBoxRAMOrdenador";
            this.txtBoxRAMOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxRAMOrdenador.TabIndex = 51;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 138);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 13);
            this.label5.TabIndex = 50;
            this.label5.Text = "Modelo";
            // 
            // txtBoxModeloOrdenador
            // 
            this.txtBoxModeloOrdenador.Location = new System.Drawing.Point(75, 135);
            this.txtBoxModeloOrdenador.Name = "txtBoxModeloOrdenador";
            this.txtBoxModeloOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxModeloOrdenador.TabIndex = 49;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "Marca";
            // 
            // txtBoxMarcaOrdenador
            // 
            this.txtBoxMarcaOrdenador.Location = new System.Drawing.Point(75, 109);
            this.txtBoxMarcaOrdenador.Name = "txtBoxMarcaOrdenador";
            this.txtBoxMarcaOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxMarcaOrdenador.TabIndex = 47;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 46;
            this.label2.Text = "Código";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 45;
            this.label1.Text = "Ordenadores:";
            // 
            // txtBoxCodigoOrdenador
            // 
            this.txtBoxCodigoOrdenador.Location = new System.Drawing.Point(75, 78);
            this.txtBoxCodigoOrdenador.Name = "txtBoxCodigoOrdenador";
            this.txtBoxCodigoOrdenador.Size = new System.Drawing.Size(100, 20);
            this.txtBoxCodigoOrdenador.TabIndex = 44;
            // 
            // btn_Siguiente_Ordenadores
            // 
            this.btn_Siguiente_Ordenadores.Location = new System.Drawing.Point(124, 280);
            this.btn_Siguiente_Ordenadores.Name = "btn_Siguiente_Ordenadores";
            this.btn_Siguiente_Ordenadores.Size = new System.Drawing.Size(75, 40);
            this.btn_Siguiente_Ordenadores.TabIndex = 80;
            this.btn_Siguiente_Ordenadores.Text = "Siguiente";
            this.btn_Siguiente_Ordenadores.UseVisualStyleBackColor = true;
            this.btn_Siguiente_Ordenadores.Click += new System.EventHandler(this.btn_Siguiente_Ordenadores_Click);
            // 
            // btn_Anterior_Ordenadores
            // 
            this.btn_Anterior_Ordenadores.Location = new System.Drawing.Point(28, 280);
            this.btn_Anterior_Ordenadores.Name = "btn_Anterior_Ordenadores";
            this.btn_Anterior_Ordenadores.Size = new System.Drawing.Size(79, 40);
            this.btn_Anterior_Ordenadores.TabIndex = 81;
            this.btn_Anterior_Ordenadores.Text = "Anterior";
            this.btn_Anterior_Ordenadores.UseVisualStyleBackColor = true;
            this.btn_Anterior_Ordenadores.Click += new System.EventHandler(this.btn_Anterior_Ordenadores_Click);
            // 
            // btn_Anterior_Moviles
            // 
            this.btn_Anterior_Moviles.Location = new System.Drawing.Point(435, 277);
            this.btn_Anterior_Moviles.Name = "btn_Anterior_Moviles";
            this.btn_Anterior_Moviles.Size = new System.Drawing.Size(79, 40);
            this.btn_Anterior_Moviles.TabIndex = 82;
            this.btn_Anterior_Moviles.Text = "Anterior";
            this.btn_Anterior_Moviles.UseVisualStyleBackColor = true;
            this.btn_Anterior_Moviles.Click += new System.EventHandler(this.btn_Anterior_Moviles_Click);
            // 
            // btn_Siguiente_Moviles
            // 
            this.btn_Siguiente_Moviles.Location = new System.Drawing.Point(520, 277);
            this.btn_Siguiente_Moviles.Name = "btn_Siguiente_Moviles";
            this.btn_Siguiente_Moviles.Size = new System.Drawing.Size(75, 40);
            this.btn_Siguiente_Moviles.TabIndex = 83;
            this.btn_Siguiente_Moviles.Text = "Siguiente";
            this.btn_Siguiente_Moviles.UseVisualStyleBackColor = true;
            this.btn_Siguiente_Moviles.Click += new System.EventHandler(this.btn_Siguiente_Moviles_Click);
            // 
            // pictureBoxPocox6pro
            // 
            this.pictureBoxPocox6pro.Image = global::Proyecto_final.Properties.Resources.pocco_x6_pro;
            this.pictureBoxPocox6pro.Location = new System.Drawing.Point(587, 57);
            this.pictureBoxPocox6pro.Name = "pictureBoxPocox6pro";
            this.pictureBoxPocox6pro.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxPocox6pro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPocox6pro.TabIndex = 88;
            this.pictureBoxPocox6pro.TabStop = false;
            this.pictureBoxPocox6pro.Visible = false;
            // 
            // pictureBoxPocoX6
            // 
            this.pictureBoxPocoX6.Image = global::Proyecto_final.Properties.Resources.Pocco_x6;
            this.pictureBoxPocoX6.Location = new System.Drawing.Point(587, 57);
            this.pictureBoxPocoX6.Name = "pictureBoxPocoX6";
            this.pictureBoxPocoX6.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxPocoX6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPocoX6.TabIndex = 89;
            this.pictureBoxPocoX6.TabStop = false;
            this.pictureBoxPocoX6.Visible = false;
            // 
            // pictureBoxRealmeC67
            // 
            this.pictureBoxRealmeC67.Image = global::Proyecto_final.Properties.Resources.realme_C67;
            this.pictureBoxRealmeC67.Location = new System.Drawing.Point(587, 57);
            this.pictureBoxRealmeC67.Name = "pictureBoxRealmeC67";
            this.pictureBoxRealmeC67.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxRealmeC67.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxRealmeC67.TabIndex = 90;
            this.pictureBoxRealmeC67.TabStop = false;
            this.pictureBoxRealmeC67.Visible = false;
            // 
            // pictureBoxDELL7010
            // 
            this.pictureBoxDELL7010.Image = global::Proyecto_final.Properties.Resources.DELL_7010_3;
            this.pictureBoxDELL7010.Location = new System.Drawing.Point(181, 57);
            this.pictureBoxDELL7010.Name = "pictureBoxDELL7010";
            this.pictureBoxDELL7010.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxDELL7010.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxDELL7010.TabIndex = 91;
            this.pictureBoxDELL7010.TabStop = false;
            this.pictureBoxDELL7010.Visible = false;
            // 
            // pictureBoxVoltier
            // 
            this.pictureBoxVoltier.Image = global::Proyecto_final.Properties.Resources.volttier;
            this.pictureBoxVoltier.Location = new System.Drawing.Point(181, 57);
            this.pictureBoxVoltier.Name = "pictureBoxVoltier";
            this.pictureBoxVoltier.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxVoltier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxVoltier.TabIndex = 92;
            this.pictureBoxVoltier.TabStop = false;
            this.pictureBoxVoltier.Visible = false;
            // 
            // pictureBoxPCCOM
            // 
            this.pictureBoxPCCOM.Image = global::Proyecto_final.Properties.Resources.PcCom_Custom_Ryzen_9;
            this.pictureBoxPCCOM.Location = new System.Drawing.Point(181, 57);
            this.pictureBoxPCCOM.Name = "pictureBoxPCCOM";
            this.pictureBoxPCCOM.Size = new System.Drawing.Size(211, 217);
            this.pictureBoxPCCOM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxPCCOM.TabIndex = 93;
            this.pictureBoxPCCOM.TabStop = false;
            this.pictureBoxPCCOM.Visible = false;
            // 
            // Cesta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 450);
            this.Controls.Add(this.pictureBoxPCCOM);
            this.Controls.Add(this.pictureBoxVoltier);
            this.Controls.Add(this.pictureBoxDELL7010);
            this.Controls.Add(this.pictureBoxRealmeC67);
            this.Controls.Add(this.pictureBoxPocoX6);
            this.Controls.Add(this.pictureBoxPocox6pro);
            this.Controls.Add(this.btn_Siguiente_Moviles);
            this.Controls.Add(this.btn_Anterior_Moviles);
            this.Controls.Add(this.btn_Anterior_Ordenadores);
            this.Controls.Add(this.btn_Siguiente_Ordenadores);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBoxHPDESKTOP);
            this.Controls.Add(this.txtBoxPrecioMovil);
            this.Controls.Add(this.txtBoxProcesadorMovil);
            this.Controls.Add(this.txtBoxCamaraMovil);
            this.Controls.Add(this.txtBoxRAMMovil);
            this.Controls.Add(this.txtBoxModeloMovil);
            this.Controls.Add(this.txtBoxMarcaMovil);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtBoxCodigoMovil);
            this.Controls.Add(this.pictureBoxRealme6i);
            this.Controls.Add(this.Precio);
            this.Controls.Add(this.txtBoxPrecioOrdenador);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtBoxProcesadorOrdenador);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtBoxSSDoHDDOrdenador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBoxRAMOrdenador);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtBoxModeloOrdenador);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBoxMarcaOrdenador);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtBoxCodigoOrdenador);
            this.Name = "Cesta";
            this.Text = "Cesta";
            this.Load += new System.EventHandler(this.Cesta_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxHPDESKTOP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRealme6i)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPocox6pro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPocoX6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxRealmeC67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDELL7010)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxVoltier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPCCOM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox pictureBoxHPDESKTOP;
        private System.Windows.Forms.TextBox txtBoxPrecioMovil;
        private System.Windows.Forms.TextBox txtBoxProcesadorMovil;
        private System.Windows.Forms.TextBox txtBoxCamaraMovil;
        private System.Windows.Forms.TextBox txtBoxRAMMovil;
        private System.Windows.Forms.TextBox txtBoxModeloMovil;
        private System.Windows.Forms.TextBox txtBoxMarcaMovil;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtBoxCodigoMovil;
        private System.Windows.Forms.PictureBox pictureBoxRealme6i;
        private System.Windows.Forms.Label Precio;
        private System.Windows.Forms.TextBox txtBoxPrecioOrdenador;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtBoxProcesadorOrdenador;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtBoxSSDoHDDOrdenador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBoxRAMOrdenador;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtBoxModeloOrdenador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBoxMarcaOrdenador;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtBoxCodigoOrdenador;
        private System.Windows.Forms.Button btn_Siguiente_Ordenadores;
        private System.Windows.Forms.Button btn_Anterior_Ordenadores;
        private System.Windows.Forms.Button btn_Anterior_Moviles;
        private System.Windows.Forms.Button btn_Siguiente_Moviles;
        private System.Windows.Forms.PictureBox pictureBoxPocox6pro;
        private System.Windows.Forms.PictureBox pictureBoxPocoX6;
        private System.Windows.Forms.PictureBox pictureBoxRealmeC67;
        private System.Windows.Forms.PictureBox pictureBoxDELL7010;
        private System.Windows.Forms.PictureBox pictureBoxVoltier;
        private System.Windows.Forms.PictureBox pictureBoxPCCOM;
    }
}