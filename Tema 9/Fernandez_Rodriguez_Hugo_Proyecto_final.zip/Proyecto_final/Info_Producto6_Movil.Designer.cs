﻿namespace Proyecto_final
{
    partial class Info_Producto6_Movil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_foto_producto = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label_Precio_Movil = new System.Windows.Forms.Label();
            this.label_Procesador_Movil = new System.Windows.Forms.Label();
            this.label_Camara_Movil = new System.Windows.Forms.Label();
            this.label_Ram_Movil = new System.Windows.Forms.Label();
            this.label_Modelo_Movil = new System.Windows.Forms.Label();
            this.label_Marca_Movil = new System.Windows.Forms.Label();
            this.label_Codigo_Movil = new System.Windows.Forms.Label();
            this.btnAñadir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_foto_producto)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_foto_producto
            // 
            this.pictureBox_foto_producto.Image = global::Proyecto_final.Properties.Resources.pocco_x6_pro;
            this.pictureBox_foto_producto.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_foto_producto.Name = "pictureBox_foto_producto";
            this.pictureBox_foto_producto.Size = new System.Drawing.Size(278, 237);
            this.pictureBox_foto_producto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_foto_producto.TabIndex = 53;
            this.pictureBox_foto_producto.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(357, 183);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 13);
            this.label6.TabIndex = 86;
            this.label6.Text = "Precio";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(357, 152);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 13);
            this.label10.TabIndex = 85;
            this.label10.Text = "Procesador";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(357, 126);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 84;
            this.label12.Text = "Camara";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(357, 100);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 13);
            this.label13.TabIndex = 83;
            this.label13.Text = "RAM";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(357, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 13);
            this.label14.TabIndex = 82;
            this.label14.Text = "Modelo";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(357, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 81;
            this.label15.Text = "Marca";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(357, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 80;
            this.label16.Text = "Código";
            // 
            // label_Precio_Movil
            // 
            this.label_Precio_Movil.AutoSize = true;
            this.label_Precio_Movil.Location = new System.Drawing.Point(433, 183);
            this.label_Precio_Movil.Name = "label_Precio_Movil";
            this.label_Precio_Movil.Size = new System.Drawing.Size(25, 13);
            this.label_Precio_Movil.TabIndex = 100;
            this.label_Precio_Movil.Text = "330";
            // 
            // label_Procesador_Movil
            // 
            this.label_Procesador_Movil.AutoSize = true;
            this.label_Procesador_Movil.Location = new System.Drawing.Point(433, 152);
            this.label_Procesador_Movil.Name = "label_Procesador_Movil";
            this.label_Procesador_Movil.Size = new System.Drawing.Size(155, 13);
            this.label_Procesador_Movil.TabIndex = 99;
            this.label_Procesador_Movil.Text = "MediaTek Dimensity 8300-Ultra";
            // 
            // label_Camara_Movil
            // 
            this.label_Camara_Movil.AutoSize = true;
            this.label_Camara_Movil.Location = new System.Drawing.Point(433, 126);
            this.label_Camara_Movil.Name = "label_Camara_Movil";
            this.label_Camara_Movil.Size = new System.Drawing.Size(38, 13);
            this.label_Camara_Movil.TabIndex = 98;
            this.label_Camara_Movil.Text = "64 MP";
            // 
            // label_Ram_Movil
            // 
            this.label_Ram_Movil.AutoSize = true;
            this.label_Ram_Movil.Location = new System.Drawing.Point(433, 100);
            this.label_Ram_Movil.Name = "label_Ram_Movil";
            this.label_Ram_Movil.Size = new System.Drawing.Size(34, 13);
            this.label_Ram_Movil.TabIndex = 97;
            this.label_Ram_Movil.Text = "12GB";
            // 
            // label_Modelo_Movil
            // 
            this.label_Modelo_Movil.AutoSize = true;
            this.label_Modelo_Movil.Location = new System.Drawing.Point(433, 69);
            this.label_Modelo_Movil.Name = "label_Modelo_Movil";
            this.label_Modelo_Movil.Size = new System.Drawing.Size(71, 13);
            this.label_Modelo_Movil.TabIndex = 96;
            this.label_Modelo_Movil.Text = "POCO X6 pro";
            // 
            // label_Marca_Movil
            // 
            this.label_Marca_Movil.AutoSize = true;
            this.label_Marca_Movil.Location = new System.Drawing.Point(433, 43);
            this.label_Marca_Movil.Name = "label_Marca_Movil";
            this.label_Marca_Movil.Size = new System.Drawing.Size(37, 13);
            this.label_Marca_Movil.TabIndex = 95;
            this.label_Marca_Movil.Text = "POCO";
            // 
            // label_Codigo_Movil
            // 
            this.label_Codigo_Movil.AutoSize = true;
            this.label_Codigo_Movil.Location = new System.Drawing.Point(433, 12);
            this.label_Codigo_Movil.Name = "label_Codigo_Movil";
            this.label_Codigo_Movil.Size = new System.Drawing.Size(61, 13);
            this.label_Codigo_Movil.TabIndex = 94;
            this.label_Codigo_Movil.Text = "798654321";
            // 
            // btnAñadir
            // 
            this.btnAñadir.Location = new System.Drawing.Point(597, 243);
            this.btnAñadir.Name = "btnAñadir";
            this.btnAñadir.Size = new System.Drawing.Size(191, 46);
            this.btnAñadir.TabIndex = 101;
            this.btnAñadir.Text = "Añadir";
            this.btnAñadir.UseVisualStyleBackColor = true;
            this.btnAñadir.Click += new System.EventHandler(this.btnAñadir_Click);
            // 
            // Info_Producto6_Movil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAñadir);
            this.Controls.Add(this.label_Precio_Movil);
            this.Controls.Add(this.label_Procesador_Movil);
            this.Controls.Add(this.label_Camara_Movil);
            this.Controls.Add(this.label_Ram_Movil);
            this.Controls.Add(this.label_Modelo_Movil);
            this.Controls.Add(this.label_Marca_Movil);
            this.Controls.Add(this.label_Codigo_Movil);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.pictureBox_foto_producto);
            this.Name = "Info_Producto6_Movil";
            this.Text = "Info_Producto6_Movil";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_foto_producto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_foto_producto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label_Precio_Movil;
        private System.Windows.Forms.Label label_Procesador_Movil;
        private System.Windows.Forms.Label label_Camara_Movil;
        private System.Windows.Forms.Label label_Ram_Movil;
        private System.Windows.Forms.Label label_Modelo_Movil;
        private System.Windows.Forms.Label label_Marca_Movil;
        private System.Windows.Forms.Label label_Codigo_Movil;
        private System.Windows.Forms.Button btnAñadir;
    }
}