﻿namespace Proyecto_final
{
    partial class Info_Producto3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ram_ordenador = new System.Windows.Forms.Label();
            this.modelo_ordenador = new System.Windows.Forms.Label();
            this.Precio = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.hdd_o_sdd_ordenador = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnAñadir = new System.Windows.Forms.Button();
            this.precio_ordenador = new System.Windows.Forms.Label();
            this.codigo_ordenador = new System.Windows.Forms.Label();
            this.procesador_ordenador = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.marca_ordenador = new System.Windows.Forms.Label();
            this.pictureBox_foto_producto = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_foto_producto)).BeginInit();
            this.SuspendLayout();
            // 
            // ram_ordenador
            // 
            this.ram_ordenador.AutoSize = true;
            this.ram_ordenador.Location = new System.Drawing.Point(431, 103);
            this.ram_ordenador.Name = "ram_ordenador";
            this.ram_ordenador.Size = new System.Drawing.Size(37, 13);
            this.ram_ordenador.TabIndex = 89;
            this.ram_ordenador.Text = "16 GB";
            // 
            // modelo_ordenador
            // 
            this.modelo_ordenador.AutoSize = true;
            this.modelo_ordenador.Location = new System.Drawing.Point(431, 72);
            this.modelo_ordenador.Name = "modelo_ordenador";
            this.modelo_ordenador.Size = new System.Drawing.Size(109, 13);
            this.modelo_ordenador.TabIndex = 88;
            this.modelo_ordenador.Text = "e4-12330F/GTX1340";
            // 
            // Precio
            // 
            this.Precio.AutoSize = true;
            this.Precio.Location = new System.Drawing.Point(357, 188);
            this.Precio.Name = "Precio";
            this.Precio.Size = new System.Drawing.Size(37, 13);
            this.Precio.TabIndex = 87;
            this.Precio.Text = "Precio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(357, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 86;
            this.label7.Text = "Procesador";
            // 
            // hdd_o_sdd_ordenador
            // 
            this.hdd_o_sdd_ordenador.AutoSize = true;
            this.hdd_o_sdd_ordenador.Location = new System.Drawing.Point(431, 128);
            this.hdd_o_sdd_ordenador.Name = "hdd_o_sdd_ordenador";
            this.hdd_o_sdd_ordenador.Size = new System.Drawing.Size(31, 13);
            this.hdd_o_sdd_ordenador.TabIndex = 85;
            this.hdd_o_sdd_ordenador.Text = "HDD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(357, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 84;
            this.label3.Text = "HDD o SSD";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(357, 103);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 83;
            this.label5.Text = "RAM";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(357, 72);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(42, 13);
            this.label13.TabIndex = 82;
            this.label13.Text = "Modelo";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(357, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 81;
            this.label14.Text = "Marca";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(357, 15);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 80;
            this.label15.Text = "Código";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(647, 62);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 79;
            this.label12.Text = "Descripción";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(594, 90);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(194, 26);
            this.label11.TabIndex = 78;
            this.label11.Text = "HP Desktop M01-F2052ns \n Intel Core i5-12400/16GB/512GB SSD";
            // 
            // btnAñadir
            // 
            this.btnAñadir.Location = new System.Drawing.Point(482, 258);
            this.btnAñadir.Name = "btnAñadir";
            this.btnAñadir.Size = new System.Drawing.Size(191, 46);
            this.btnAñadir.TabIndex = 76;
            this.btnAñadir.Text = "Añadir";
            this.btnAñadir.UseVisualStyleBackColor = true;
            this.btnAñadir.Click += new System.EventHandler(this.btnAñadir_Click);
            // 
            // precio_ordenador
            // 
            this.precio_ordenador.AutoSize = true;
            this.precio_ordenador.Location = new System.Drawing.Point(431, 188);
            this.precio_ordenador.Name = "precio_ordenador";
            this.precio_ordenador.Size = new System.Drawing.Size(25, 13);
            this.precio_ordenador.TabIndex = 75;
            this.precio_ordenador.Text = "250";
            // 
            // codigo_ordenador
            // 
            this.codigo_ordenador.AutoSize = true;
            this.codigo_ordenador.Location = new System.Drawing.Point(431, 15);
            this.codigo_ordenador.Name = "codigo_ordenador";
            this.codigo_ordenador.Size = new System.Drawing.Size(61, 13);
            this.codigo_ordenador.TabIndex = 74;
            this.codigo_ordenador.Text = "213456789";
            // 
            // procesador_ordenador
            // 
            this.procesador_ordenador.AutoSize = true;
            this.procesador_ordenador.Location = new System.Drawing.Point(431, 158);
            this.procesador_ordenador.Name = "procesador_ordenador";
            this.procesador_ordenador.Size = new System.Drawing.Size(99, 13);
            this.procesador_ordenador.TabIndex = 73;
            this.procesador_ordenador.Text = " Intel Core i5-12500";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(392, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 13);
            this.label4.TabIndex = 72;
            this.label4.Text = "SSD";
            // 
            // marca_ordenador
            // 
            this.marca_ordenador.AutoSize = true;
            this.marca_ordenador.Location = new System.Drawing.Point(431, 46);
            this.marca_ordenador.Name = "marca_ordenador";
            this.marca_ordenador.Size = new System.Drawing.Size(133, 13);
            this.marca_ordenador.TabIndex = 71;
            this.marca_ordenador.Text = "HP Desktop M01-F2052ns";
            // 
            // pictureBox_foto_producto
            // 
            this.pictureBox_foto_producto.Image = global::Proyecto_final.Properties.Resources.HP_Desktop_M01_F2052ns;
            this.pictureBox_foto_producto.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_foto_producto.Name = "pictureBox_foto_producto";
            this.pictureBox_foto_producto.Size = new System.Drawing.Size(278, 237);
            this.pictureBox_foto_producto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_foto_producto.TabIndex = 77;
            this.pictureBox_foto_producto.TabStop = false;
            // 
            // Info_Producto3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ram_ordenador);
            this.Controls.Add(this.modelo_ordenador);
            this.Controls.Add(this.Precio);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.hdd_o_sdd_ordenador);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox_foto_producto);
            this.Controls.Add(this.btnAñadir);
            this.Controls.Add(this.precio_ordenador);
            this.Controls.Add(this.codigo_ordenador);
            this.Controls.Add(this.procesador_ordenador);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.marca_ordenador);
            this.Name = "Info_Producto3";
            this.Text = "Info_Producto3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_foto_producto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ram_ordenador;
        private System.Windows.Forms.Label modelo_ordenador;
        private System.Windows.Forms.Label Precio;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label hdd_o_sdd_ordenador;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox_foto_producto;
        private System.Windows.Forms.Button btnAñadir;
        private System.Windows.Forms.Label precio_ordenador;
        private System.Windows.Forms.Label codigo_ordenador;
        private System.Windows.Forms.Label procesador_ordenador;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label marca_ordenador;
    }
}