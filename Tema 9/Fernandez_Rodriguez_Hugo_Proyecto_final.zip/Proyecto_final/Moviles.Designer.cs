﻿namespace Proyecto_final
{
    partial class Moviles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox_Movil_4 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Movil_3 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Movil_2 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Movil_1 = new System.Windows.Forms.PictureBox();
            this.btn_Buscar_Codigo_Movil = new System.Windows.Forms.Button();
            this.txtBox_Buscar_Por_Codigo_Movil = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.comboBox_Procesadores_Movil = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.comboBoxRango_De_Precios_Movil = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioBtn_Camara_Todos_Moviles = new System.Windows.Forms.RadioButton();
            this.radioBtn_Camara_100a200_Moviles = new System.Windows.Forms.RadioButton();
            this.radioBtn_Camara_0a100_Moviles = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox_Movil_4
            // 
            this.pictureBox_Movil_4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Movil_4.Image = global::Proyecto_final.Properties.Resources.Pocco_x6;
            this.pictureBox_Movil_4.Location = new System.Drawing.Point(457, 190);
            this.pictureBox_Movil_4.Name = "pictureBox_Movil_4";
            this.pictureBox_Movil_4.Size = new System.Drawing.Size(112, 95);
            this.pictureBox_Movil_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Movil_4.TabIndex = 33;
            this.pictureBox_Movil_4.TabStop = false;
            this.pictureBox_Movil_4.Visible = false;
            this.pictureBox_Movil_4.Click += new System.EventHandler(this.pictureBox_Movil_4_Click);
            // 
            // pictureBox_Movil_3
            // 
            this.pictureBox_Movil_3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Movil_3.Image = global::Proyecto_final.Properties.Resources.realme_6i;
            this.pictureBox_Movil_3.Location = new System.Drawing.Point(269, 183);
            this.pictureBox_Movil_3.Name = "pictureBox_Movil_3";
            this.pictureBox_Movil_3.Size = new System.Drawing.Size(112, 95);
            this.pictureBox_Movil_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Movil_3.TabIndex = 32;
            this.pictureBox_Movil_3.TabStop = false;
            this.pictureBox_Movil_3.Visible = false;
            this.pictureBox_Movil_3.Click += new System.EventHandler(this.pictureBox_Movil_3_Click);
            // 
            // pictureBox_Movil_2
            // 
            this.pictureBox_Movil_2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Movil_2.Image = global::Proyecto_final.Properties.Resources.pocco_x6_pro;
            this.pictureBox_Movil_2.Location = new System.Drawing.Point(457, 46);
            this.pictureBox_Movil_2.Name = "pictureBox_Movil_2";
            this.pictureBox_Movil_2.Size = new System.Drawing.Size(112, 95);
            this.pictureBox_Movil_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Movil_2.TabIndex = 31;
            this.pictureBox_Movil_2.TabStop = false;
            this.pictureBox_Movil_2.Visible = false;
            this.pictureBox_Movil_2.Click += new System.EventHandler(this.pictureBox_Movil_2_Click);
            // 
            // pictureBox_Movil_1
            // 
            this.pictureBox_Movil_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox_Movil_1.Image = global::Proyecto_final.Properties.Resources.realme_C67;
            this.pictureBox_Movil_1.Location = new System.Drawing.Point(269, 46);
            this.pictureBox_Movil_1.Name = "pictureBox_Movil_1";
            this.pictureBox_Movil_1.Size = new System.Drawing.Size(112, 95);
            this.pictureBox_Movil_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Movil_1.TabIndex = 30;
            this.pictureBox_Movil_1.TabStop = false;
            this.pictureBox_Movil_1.Visible = false;
            this.pictureBox_Movil_1.Click += new System.EventHandler(this.pictureBox_Movil_1_Click);
            // 
            // btn_Buscar_Codigo_Movil
            // 
            this.btn_Buscar_Codigo_Movil.Location = new System.Drawing.Point(118, 253);
            this.btn_Buscar_Codigo_Movil.Name = "btn_Buscar_Codigo_Movil";
            this.btn_Buscar_Codigo_Movil.Size = new System.Drawing.Size(98, 42);
            this.btn_Buscar_Codigo_Movil.TabIndex = 39;
            this.btn_Buscar_Codigo_Movil.Text = "Buscar por codigo";
            this.btn_Buscar_Codigo_Movil.UseVisualStyleBackColor = true;
            this.btn_Buscar_Codigo_Movil.Click += new System.EventHandler(this.btn_Buscar_Codigo_Movil_Click);
            // 
            // txtBox_Buscar_Por_Codigo_Movil
            // 
            this.txtBox_Buscar_Por_Codigo_Movil.Location = new System.Drawing.Point(12, 265);
            this.txtBox_Buscar_Por_Codigo_Movil.Name = "txtBox_Buscar_Por_Codigo_Movil";
            this.txtBox_Buscar_Por_Codigo_Movil.Size = new System.Drawing.Size(100, 20);
            this.txtBox_Buscar_Por_Codigo_Movil.TabIndex = 38;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.comboBox_Procesadores_Movil);
            this.groupBox3.Location = new System.Drawing.Point(16, 178);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(123, 69);
            this.groupBox3.TabIndex = 37;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Procesadores";
            // 
            // comboBox_Procesadores_Movil
            // 
            this.comboBox_Procesadores_Movil.FormattingEnabled = true;
            this.comboBox_Procesadores_Movil.Items.AddRange(new object[] {
            "Todos",
            "Snapdragon",
            "Mediatek"});
            this.comboBox_Procesadores_Movil.Location = new System.Drawing.Point(6, 19);
            this.comboBox_Procesadores_Movil.Name = "comboBox_Procesadores_Movil";
            this.comboBox_Procesadores_Movil.Size = new System.Drawing.Size(95, 21);
            this.comboBox_Procesadores_Movil.TabIndex = 0;
            this.comboBox_Procesadores_Movil.SelectedIndexChanged += new System.EventHandler(this.comboBox_Procesadores_Movil_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.comboBoxRango_De_Precios_Movil);
            this.groupBox2.Location = new System.Drawing.Point(16, 99);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(123, 73);
            this.groupBox2.TabIndex = 36;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rangos de precios:";
            // 
            // comboBoxRango_De_Precios_Movil
            // 
            this.comboBoxRango_De_Precios_Movil.FormattingEnabled = true;
            this.comboBoxRango_De_Precios_Movil.Items.AddRange(new object[] {
            "Todos",
            "0-200",
            "200-300",
            "300-400"});
            this.comboBoxRango_De_Precios_Movil.Location = new System.Drawing.Point(6, 19);
            this.comboBoxRango_De_Precios_Movil.Name = "comboBoxRango_De_Precios_Movil";
            this.comboBoxRango_De_Precios_Movil.Size = new System.Drawing.Size(95, 21);
            this.comboBoxRango_De_Precios_Movil.TabIndex = 0;
            this.comboBoxRango_De_Precios_Movil.SelectedIndexChanged += new System.EventHandler(this.comboBoxRango_De_Precios_Movil_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioBtn_Camara_Todos_Moviles);
            this.groupBox1.Controls.Add(this.radioBtn_Camara_100a200_Moviles);
            this.groupBox1.Controls.Add(this.radioBtn_Camara_0a100_Moviles);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(105, 81);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Camara mp";
            // 
            // radioBtn_Camara_Todos_Moviles
            // 
            this.radioBtn_Camara_Todos_Moviles.AutoSize = true;
            this.radioBtn_Camara_Todos_Moviles.Location = new System.Drawing.Point(4, 19);
            this.radioBtn_Camara_Todos_Moviles.Name = "radioBtn_Camara_Todos_Moviles";
            this.radioBtn_Camara_Todos_Moviles.Size = new System.Drawing.Size(55, 17);
            this.radioBtn_Camara_Todos_Moviles.TabIndex = 11;
            this.radioBtn_Camara_Todos_Moviles.TabStop = true;
            this.radioBtn_Camara_Todos_Moviles.Text = "Todos";
            this.radioBtn_Camara_Todos_Moviles.UseVisualStyleBackColor = true;
            this.radioBtn_Camara_Todos_Moviles.CheckedChanged += new System.EventHandler(this.radioBtn_Camara_Todos_Moviles_CheckedChanged);
            // 
            // radioBtn_Camara_100a200_Moviles
            // 
            this.radioBtn_Camara_100a200_Moviles.AutoSize = true;
            this.radioBtn_Camara_100a200_Moviles.Location = new System.Drawing.Point(4, 58);
            this.radioBtn_Camara_100a200_Moviles.Name = "radioBtn_Camara_100a200_Moviles";
            this.radioBtn_Camara_100a200_Moviles.Size = new System.Drawing.Size(64, 17);
            this.radioBtn_Camara_100a200_Moviles.TabIndex = 10;
            this.radioBtn_Camara_100a200_Moviles.TabStop = true;
            this.radioBtn_Camara_100a200_Moviles.Text = "100-200";
            this.radioBtn_Camara_100a200_Moviles.UseVisualStyleBackColor = true;
            this.radioBtn_Camara_100a200_Moviles.CheckedChanged += new System.EventHandler(this.radioBtn_Camara_100a200_Moviles_CheckedChanged);
            // 
            // radioBtn_Camara_0a100_Moviles
            // 
            this.radioBtn_Camara_0a100_Moviles.AutoSize = true;
            this.radioBtn_Camara_0a100_Moviles.Location = new System.Drawing.Point(4, 42);
            this.radioBtn_Camara_0a100_Moviles.Name = "radioBtn_Camara_0a100_Moviles";
            this.radioBtn_Camara_0a100_Moviles.Size = new System.Drawing.Size(52, 17);
            this.radioBtn_Camara_0a100_Moviles.TabIndex = 10;
            this.radioBtn_Camara_0a100_Moviles.TabStop = true;
            this.radioBtn_Camara_0a100_Moviles.Text = "0-100";
            this.radioBtn_Camara_0a100_Moviles.UseVisualStyleBackColor = true;
            this.radioBtn_Camara_0a100_Moviles.CheckedChanged += new System.EventHandler(this.radioBtn_Camara_0a100_Moviles_CheckedChanged);
            // 
            // Moviles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Buscar_Codigo_Movil);
            this.Controls.Add(this.txtBox_Buscar_Por_Codigo_Movil);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox_Movil_4);
            this.Controls.Add(this.pictureBox_Movil_3);
            this.Controls.Add(this.pictureBox_Movil_2);
            this.Controls.Add(this.pictureBox_Movil_1);
            this.Name = "Moviles";
            this.Text = "Moviles";
            this.Load += new System.EventHandler(this.Moviles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Movil_1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_Movil_1;
        private System.Windows.Forms.PictureBox pictureBox_Movil_2;
        private System.Windows.Forms.PictureBox pictureBox_Movil_3;
        private System.Windows.Forms.PictureBox pictureBox_Movil_4;
        private System.Windows.Forms.Button btn_Buscar_Codigo_Movil;
        private System.Windows.Forms.TextBox txtBox_Buscar_Por_Codigo_Movil;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox comboBox_Procesadores_Movil;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox comboBoxRango_De_Precios_Movil;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioBtn_Camara_Todos_Moviles;
        private System.Windows.Forms.RadioButton radioBtn_Camara_100a200_Moviles;
        private System.Windows.Forms.RadioButton radioBtn_Camara_0a100_Moviles;
    }
}